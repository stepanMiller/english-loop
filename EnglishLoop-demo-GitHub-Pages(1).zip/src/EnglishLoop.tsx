import React, { useState, useEffect, useRef } from "react";
import {
  Home, Users, ClipboardList, BookOpen, Settings, Plus, ChevronRight, ArrowLeft,
  Check, X, Mic, Square, Play, Pause, Calendar, Send, Trash2, ArrowUp, ArrowDown,
  RotateCcw, MessageSquare, TrendingUp, PenLine, Languages, Target,
  CheckCircle2, Circle, Pencil, Volume2, Sparkles
} from "./icons";

/* ------------------------------------------------------------------ *
 *  ENGLISH LOOP — Concept B: Homework Practice Loop
 *  Teacher assigns → Student practises → Teacher reviews → Next lesson.
 *  Clickable prototype. Mock data, local state, simulated interactions.
 * ------------------------------------------------------------------ */

const CSS = `
.el-root{--bg:#FAF9F6;--surface:#FFFFFF;--sunk:#F4F2ED;--ink:#1B1A17;--ink2:#5B584F;--ink3:#918C81;
--line:#E9E4DA;--line2:#DAD3C6;--accent:#1F5E4E;--accent-h:#17493D;--soft:#E9F0ED;
--amber:#8F6320;--amber-s:#F8F0E2;--blue:#3B5C88;--blue-s:#EDF1F7;
--sans:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
--serif:"Iowan Old Style","Palatino Linotype",Palatino,"Book Antiqua",Georgia,serif;
--mono:ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,monospace;
background:var(--bg);color:var(--ink);font-family:var(--sans);-webkit-font-smoothing:antialiased;
font-size:15px;line-height:1.5;min-height:100vh}
.el-root *{box-sizing:border-box}
.el-root button{font:inherit;color:inherit;cursor:pointer;border:none;background:none}
.el-serif{font-family:var(--serif);font-weight:400;letter-spacing:-.015em;line-height:1.18}
.el-mono{font-family:var(--mono);font-variant-numeric:tabular-nums;letter-spacing:-.02em}
.el-eyebrow{font-size:11px;font-weight:600;letter-spacing:.13em;text-transform:uppercase;color:var(--ink3)}
.el-card{background:var(--surface);border:1px solid var(--line);border-radius:16px}
.el-lift{transition:transform .2s cubic-bezier(.2,.7,.3,1),box-shadow .2s,border-color .2s}
.el-lift:hover{border-color:var(--line2);box-shadow:0 10px 30px -18px rgba(27,26,23,.35);transform:translateY(-1px)}
.el-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border-radius:11px;
font-weight:530;font-size:14px;padding:10px 16px;transition:background .16s,transform .12s,border-color .16s,color .16s;white-space:nowrap}
.el-btn:active{transform:scale(.985)}
.el-btn:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.el-p{background:var(--accent);color:#fff}
.el-p:hover{background:var(--accent-h)}
.el-p[disabled]{background:var(--line2);color:#fff;cursor:not-allowed}
.el-g{background:var(--surface);border:1px solid var(--line);color:var(--ink)}
.el-g:hover{border-color:var(--line2);background:#fff}
.el-q{color:var(--ink2);padding:8px 10px}
.el-q:hover{color:var(--ink);background:var(--sunk)}
.el-in,.el-ta{width:100%;background:var(--surface);border:1px solid var(--line);border-radius:12px;
padding:11px 13px;font:inherit;color:var(--ink);outline:none;transition:border-color .15s,box-shadow .15s}
.el-ta{resize:vertical;line-height:1.62}
.el-in:focus,.el-ta:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(31,94,78,.09)}
.el-in::placeholder,.el-ta::placeholder{color:var(--ink3)}
.el-pill{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:4px 10px;font-size:12px;font-weight:560;letter-spacing:.005em}
.el-chip{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:6px 12px;font-size:13px;
border:1px solid var(--line);background:var(--surface);color:var(--ink2);transition:all .16s}
.el-chip:hover{border-color:var(--line2);color:var(--ink)}
.el-chip-on{background:var(--accent);border-color:var(--accent);color:#fff}
.el-chip-on:hover{background:var(--accent-h);color:#fff}
.el-fade{animation:elFade .34s cubic-bezier(.2,.7,.3,1)}
@keyframes elFade{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:none}}
.el-fadein{animation:elFadeIn .3s ease}
@keyframes elFadeIn{from{opacity:0}to{opacity:1}}
.el-pop{animation:elPop .4s cubic-bezier(.2,1.2,.35,1)}
@keyframes elPop{from{opacity:0;transform:scale(.94)}to{opacity:1;transform:none}}
.el-rec{animation:elRec 2s ease-out infinite}
@keyframes elRec{0%{box-shadow:0 0 0 0 rgba(143,99,32,.30)}70%{box-shadow:0 0 0 26px rgba(143,99,32,0)}100%{box-shadow:0 0 0 0 rgba(143,99,32,0)}}
.el-scroll{overflow-y:auto;scrollbar-width:thin}
.el-scroll::-webkit-scrollbar{width:8px;height:8px}
.el-scroll::-webkit-scrollbar-thumb{background:#E2DCD0;border-radius:99px;border:2px solid var(--bg)}
.el-nav{display:flex;align-items:center;gap:10px;width:100%;padding:8px 11px;border-radius:10px;
font-size:14px;color:var(--ink2);transition:background .15s,color .15s}
.el-nav:hover{background:var(--sunk);color:var(--ink)}
.el-nav-on{background:var(--sunk);color:var(--ink);font-weight:560}
.el-phone{width:392px;border-radius:40px;border:1px solid var(--line2);background:#fff;
box-shadow:0 50px 90px -50px rgba(27,26,23,.5),0 0 0 9px #EFEDE7;overflow:hidden}
.el-mark{background:var(--amber-s);border-bottom:1.5px solid #DBBE8C;cursor:pointer;border-radius:3px;padding:1px 2px;transition:background .15s}
.el-mark:hover{background:#F3E5CB}
.el-mark-good{background:var(--soft);border-bottom:1.5px solid #A9C7BC;cursor:pointer;border-radius:3px;padding:1px 2px}
.el-tg{background:var(--soft);border-radius:4px;padding:1px 3px;color:#194C3F;font-weight:500}
.el-bar{height:3px;border-radius:99px;background:var(--line);overflow:hidden}
.el-bar>span{display:block;height:100%;background:var(--accent);border-radius:99px;transition:width .5s cubic-bezier(.2,.7,.3,1)}
@media (prefers-reduced-motion:reduce){.el-root *{animation:none!important;transition:none!important}}
`;

/* ------------------------------ mock data ------------------------------ */

const EXPRESSIONS = [
  "despite being criticized", "as soon as the report is signed", "think twice before stepping in",
  "against the odds", "reach an agreement", "look into", "put off", "clear up all my doubts",
  "carry out", "in advance", "step in", "eventually", "keep going towards the goal",
];

const RECALL_ITEMS = [
  { ru: "Несмотря на критику, он продолжал двигаться к своей цели.", en: "Despite being criticized, he kept going towards his goal.", key: ["despite being criticized", "kept going"] },
  { ru: "Как только отчёт будет подписан, мы начнём работу.", en: "As soon as the report is signed, we will start working.", key: ["as soon as the report is signed"] },
  { ru: "Подумай дважды, прежде чем вмешиваться.", en: "Think twice before stepping in.", key: ["think twice", "stepping in"] },
  { ru: "Я разберусь с этим до конца недели.", en: "I will look into it before the end of the week.", key: ["look into"] },
  { ru: "Встречу пришлось отложить до понедельника.", en: "The meeting had to be put off until Monday.", key: ["put off"] },
  { ru: "Он всё объяснил и развеял все мои сомнения.", en: "He explained everything and cleared up all my doubts.", key: ["cleared up all my doubts"] },
  { ru: "Мы забронировали всё заранее.", en: "We booked everything in advance.", key: ["in advance"] },
  { ru: "В итоге нам удалось прийти к соглашению.", en: "Eventually we managed to reach an agreement.", key: ["eventually", "reach an agreement"] },
];

const GRAMMAR_ITEMS = [
  { s: "If I ___ about the delay, I would have changed the plan.", o: ["knew", "had known", "would know"], a: 1, tag: "Third Conditional", why: "Third Conditional: if + had + V3 в условии." },
  { s: "The report ___ by the whole team before the meeting.", o: ["had checked", "was checking", "had been checked"], a: 2, tag: "Passive Voice", why: "Действие с отчётом сделали другие — нужен пассив в past perfect." },
  { s: "___ the documents are signed, we can start.", o: ["As soon as", "Until", "Despite"], a: 0, tag: "as soon as", why: "«Как только» — as soon as + Present Simple о будущем." },
  { s: "We didn't leave the office ___ everything was clear.", o: ["before", "until", "as soon as"], a: 1, tag: "until", why: "«Не уходили, пока не…» — until." },
  { s: "If she had looked into the issue earlier, she ___ the problem.", o: ["would have solved", "would solve", "solved"], a: 0, tag: "Third Conditional", why: "Вторая часть Third Conditional: would have + V3." },
];

const SPEAK_TARGETS = ["eventually", "look into", "carry out", "in advance", "keep going", "despite"];

const MOCK_TRANSCRIPT =
  "Last Tuesday was a really demanding day for me. In advance I had planned to finish the report and after that to meet my colleague, but in the morning the client called and asked to change almost everything. Despite this situation I keep going and I tried to solve the problems one by one. First I rewrote the numbers, then I asked my colleague about the second part. Eventually we finished the report at eight o'clock in the evening. I was very tired, but I was satisfied because we did not lose the client.";

const ESSAY_PARTS = [
  { t: "Last month my team had planned a presentation for an important client. Everything was prepared " },
  { t: "in advance", tag: "target" },
  { t: ", and we were sure about the result. Two hours before the meeting the client wrote that he could join only online. " },
  { t: "If we had known about it earlier, we would have prepared a different version of the slides.", tag: "good", id: "g1", note: "Third Conditional построено верно — ровно то, что отрабатывали на уроке." },
  { t: " We had to change the plan very quickly. I asked my colleague to " },
  { t: "look into", tag: "target" },
  { t: " technical part", tag: "fix", id: "a1", note: "Пропущен артикль: “to look into the technical part”." },
  { t: " while I was rewriting the first section. " },
  { t: "Despite", tag: "target" },
  { t: " the pressure, we " },
  { t: "kept going", tag: "target" },
  { t: " and " },
  { t: "eventually", tag: "target" },
  { t: " the presentation was " },
  { t: "carried out", tag: "target" },
  { t: " without serious problems. The client said that he liked our flexibility. " },
  { t: "Now I always prepare a second scenario in advance, because a plan can be changed in any moment", tag: "fix", id: "a2", note: "Предлог: “at any moment”. И лучше разбить длинное предложение на два." },
  { t: ", and it is better to be ready than to lose the client." },
];

const SAMPLE_ESSAY =
  "Last month my team had planned a presentation for an important client. Everything was prepared in advance, and we were sure about the result. Two hours before the meeting the client wrote that he could join only online. If we had known about it earlier, we would have prepared a different version of the slides. We had to change the plan very quickly. I asked my colleague to look into technical part while I was rewriting the first section. Despite the pressure, we kept going and eventually the presentation was carried out without serious problems. The client said that he liked our flexibility. Now I always prepare a second scenario in advance, because a plan can be changed in any moment, and it is better to be ready than to lose the client.";

const WRITE_TARGETS = ["in advance", "look into", "carry out", "eventually", "keep going", "despite"];

const GOALS = [
  "Use target expressions without prompts",
  "Speak continuously for two minutes",
  "Practise Third Conditional",
  "Improve spontaneous speaking",
  "Review mistakes from the previous lesson",
];

const LIBRARY = [
  {
    id: "vocab", type: "vocab", icon: "Languages", title: "Vocabulary Recall", minutes: 7,
    subtitle: "Russian → English · 8 expressions",
    why: "13 активных выражений, 4 из них не всплывали две недели",
    settings: { direction: "Russian → English", count: 8 },
  },
  {
    id: "speaking", type: "speaking", icon: "Mic", title: "Speaking", minutes: 8,
    subtitle: "A demanding day · 2 minutes",
    why: "На уроке речь рвалась на 40-й секунде",
    prompt: "Describe a demanding day when you had to deal with several problems.",
    targets: SPEAK_TARGETS,
    target: "Speak for 2 minutes without reading a prepared text.",
  },
  {
    id: "writing", type: "writing", icon: "PenLine", title: "Writing", minutes: 15,
    subtitle: "Changed plans · 120–160 words",
    why: "Third Conditional в письме пока не появляется сам",
    prompt: "Write about a situation when a plan had to be changed unexpectedly.",
    reqs: ["120–160 words", "use Third Conditional at least once", "use three target expressions", "check articles and sentence structure"],
  },
  {
    id: "grammar", type: "grammar", icon: "Target", title: "Grammar in Context", minutes: 7,
    subtitle: "Third Conditional · Passive · as soon as",
    why: "Ошибки в Passive на прошлом занятии",
    focus: ["Third Conditional", "Passive Voice", "as soon as / before / until"],
    settings: { count: 5 },
  },
];

const STUDENTS = [
  { id: "ahav", name: "Ahav", tracks: ["General English", "IELTS"], nextLesson: "Четверг, 19:00", level: "B2", since: "ноябрь 2024" },
  { id: "alex", name: "Alex Morozov", tracks: ["IELTS"], nextLesson: "Пятница, 10:00", level: "B2+", since: "февраль 2025" },
  { id: "michael", name: "Michael Green", tracks: ["GMAT"], nextLesson: "Суббота, 12:00", level: "C1", since: "январь 2025" },
  { id: "nina", name: "Nina Sokolova", tracks: ["General English", "TOEFL"], nextLesson: "Понедельник, 18:30", level: "B1+", since: "март 2025" },
];

const STATUS = {
  assigned: { label: "Assigned", fg: "#5B584F", bg: "#F1EFE9" },
  in_progress: { label: "In progress", fg: "#3B5C88", bg: "#EDF1F7" },
  submitted: { label: "Submitted", fg: "#1F5E4E", bg: "#E9F0ED" },
  needs_review: { label: "Needs review", fg: "#8F6320", bg: "#F8F0E2" },
  feedback_sent: { label: "Feedback sent", fg: "#1F5E4E", bg: "#E9F0ED" },
  overdue: { label: "Overdue", fg: "#9A4B3C", bg: "#F8EAE6" },
};

const initialHomework = () => ({
  "hw-ahav-tue": {
    id: "hw-ahav-tue", student: "ahav", title: "Tuesday practice", status: "needs_review",
    due: "Вторник, 20:00", submittedLabel: "18 минут назад", totalTime: 34,
    goals: [GOALS[0], GOALS[1], GOALS[2]],
    tasks: [
      { ...LIBRARY[0], minutes: 7 }, { ...LIBRARY[1], minutes: 8 },
      { ...LIBRARY[2], minutes: 15 }, { ...LIBRARY[3], minutes: 7 },
    ],
    submission: {
      recall: { confident: 6, retry: 2, retryItems: ["look into", "carry out"] },
      speaking: { duration: "2:04", seconds: 124, transcript: MOCK_TRANSCRIPT, used: ["eventually", "in advance", "keep going", "despite"] },
      writing: { words: 142, text: SAMPLE_ESSAY, used: ["in advance", "look into", "carry out"] },
      grammar: { correct: 4, total: 5, missed: ["Passive Voice"] },
    },
    feedback: null,
  },
  "hw-ahav-thu": {
    id: "hw-ahav-thu", student: "ahav", title: "Thursday practice", status: "assigned",
    due: "Среда, 20:00", nextLesson: "Четверг",
    goals: [GOALS[0], GOALS[1], GOALS[2]],
    tasks: [
      { ...LIBRARY[0], minutes: 7 }, { ...LIBRARY[1], minutes: 8 },
      { ...LIBRARY[2], minutes: 15 }, { ...LIBRARY[3], minutes: 7 },
    ],
    submission: {}, feedback: null,
  },
  "hw-alex": {
    id: "hw-alex", student: "alex", title: "IELTS practice", status: "needs_review",
    due: "Вчера, 21:00", submittedLabel: "вчера", totalTime: 41,
    goals: ["Structure a Task 2 argument", "Reduce repetition in linking"],
    tasks: [{ ...LIBRARY[2], title: "IELTS Writing Task 2", subtitle: "Task 2 · 250+ words", minutes: 40 }],
    submission: { writing: { words: 247, text: SAMPLE_ESSAY, used: ["in advance", "eventually"] } },
    feedback: null,
  },
  "hw-michael": {
    id: "hw-michael", student: "michael", title: "GMAT Critical Reasoning", status: "in_progress",
    due: "Завтра, 09:00", progressLabel: "8 of 12 questions completed",
    goals: ["Spot assumption gaps faster"],
    tasks: [{ ...LIBRARY[3], title: "GMAT Critical Reasoning", subtitle: "12 questions · assumptions", minutes: 25 }],
    submission: { grammar: { correct: 6, total: 8, missed: ["Assumption"] } }, feedback: null,
  },
  "hw-nina": {
    id: "hw-nina", student: "nina", title: "TOEFL speaking warm-up", status: "overdue",
    due: "Понедельник, 20:00",
    goals: ["Speak 45 seconds without pauses"],
    tasks: [{ ...LIBRARY[1], minutes: 12 }],
    submission: {}, feedback: null,
  },
});

const PROGRESS = {
  automatic: [
    { t: "as soon as", note: "Стабильно в речи и письме с 4 марта" },
    { t: "keep going", note: "Автоматически после трёх Speaking-заданий" },
    { t: "in advance", note: "Без подсказок в последних двух работах" },
  ],
  stronger: [
    { t: "eventually", note: "Перешло сюда после двух успешных Speaking-заданий" },
    { t: "Third Conditional", note: "Появилось само в Writing 18 марта" },
    { t: "speaking continuously", note: "2:04 без чтения текста" },
  ],
  practice: [
    { t: "look into", note: "Не всплыло в последнем Speaking" },
    { t: "carry out", note: "Пока только с подсказкой в списке" },
    { t: "articles", note: "Две правки в последнем Writing" },
    { t: "spontaneous speaking", note: "Речь рвётся без плана" },
  ],
};

const CORE_SKILLS = [
  { s: "Vocabulary", v: 2 }, { s: "Grammar", v: 2 }, { s: "Reading", v: 3 },
  { s: "Writing", v: 2 }, { s: "Listening", v: 3 }, { s: "Speaking", v: 1 },
];
const SKILL_STATE = ["Needs practice", "Getting stronger", "Automatic"];

/* ------------------------------ helpers ------------------------------ */

const norm = (s) => s.toLowerCase().replace(/[.,!?;:'"«»]/g, "").replace(/\s+/g, " ").trim();
const countWords = (s) => (s.trim() ? s.trim().split(/\s+/).length : 0);
const mmss = (n) => `${Math.floor(n / 60)}:${String(n % 60).padStart(2, "0")}`;
const usedTargets = (text, list) => list.filter((t) => norm(text).includes(norm(t)));

const STORAGE_KEY = "english-loop-homework-v3";
const AUDIO_DB = "english-loop-audio";
const AUDIO_STORE = "recordings";

function loadHomework() {
  if (typeof window === "undefined") return initialHomework();
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : initialHomework();
  } catch {
    return initialHomework();
  }
}

function openAudioDb() {
  return new Promise((resolve, reject) => {
    if (!("indexedDB" in window)) return reject(new Error("IndexedDB is unavailable"));
    const request = indexedDB.open(AUDIO_DB, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(AUDIO_STORE)) db.createObjectStore(AUDIO_STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Could not open local audio storage"));
  });
}

async function saveAudioBlob(key, blob) {
  const db = await openAudioDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(AUDIO_STORE, "readwrite");
    tx.objectStore(AUDIO_STORE).put(blob, key);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("Could not save audio"));
  });
  db.close();
}

async function loadAudioBlob(key) {
  const db = await openAudioDb();
  const blob = await new Promise((resolve, reject) => {
    const request = db.transaction(AUDIO_STORE, "readonly").objectStore(AUDIO_STORE).get(key);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error || new Error("Could not load audio"));
  });
  db.close();
  return blob;
}

async function clearAudioBlobs() {
  try {
    const db = await openAudioDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(AUDIO_STORE, "readwrite");
      tx.objectStore(AUDIO_STORE).clear();
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // Audio storage is optional; reset the rest of the demo regardless.
  }
}

function speakingMimeType() {
  if (typeof MediaRecorder === "undefined" || typeof MediaRecorder.isTypeSupported !== "function") return "";
  return ["audio/mp4", "audio/webm;codecs=opus", "audio/webm"].find((t) => MediaRecorder.isTypeSupported(t)) || "";
}

function useNarrow(bp = 940) {
  const [n, setN] = useState(typeof window !== "undefined" ? window.innerWidth < bp : false);
  useEffect(() => {
    const f = () => setN(window.innerWidth < bp);
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, [bp]);
  return n;
}

const ICONS = { Languages, Mic, PenLine, Target };
const TaskIcon = ({ name, size = 16, ...p }) => {
  const C = ICONS[name] || Target;
  return <C size={size} {...p} />;
};

function Pill({ status, children }) {
  const s = STATUS[status] || { label: children, fg: "#5B584F", bg: "#F1EFE9" };
  return <span className="el-pill" style={{ background: s.bg, color: s.fg }}>{s.label}</span>;
}

function Toast({ show, children }) {
  if (!show) return null;
  return (
    <div className="el-pop" style={{
      position: "fixed", bottom: 26, left: "50%", transform: "translateX(-50%)", zIndex: 90,
      background: "#1B1A17", color: "#fff", padding: "11px 18px", borderRadius: 12,
      fontSize: 14, fontWeight: 500, boxShadow: "0 20px 40px -20px rgba(0,0,0,.6)", display: "flex", gap: 9, alignItems: "center",
    }}>
      <Check size={15} strokeWidth={2.4} /> {children}
    </div>
  );
}

/* Signature element: the loop rail. Shows where the teacher is in the cycle. */
function LoopRail({ stage }) {
  const steps = [
    { k: "assign", l: "Assign" }, { k: "practise", l: "Practise" },
    { k: "review", l: "Review" }, { k: "lesson", l: "Next lesson" },
  ];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
      {steps.map((s, i) => {
        const on = s.k === stage;
        return (
          <React.Fragment key={s.k}>
            <span className="el-mono" style={{
              fontSize: 11, letterSpacing: ".08em", textTransform: "uppercase",
              color: on ? "var(--accent)" : "var(--ink3)", fontWeight: on ? 600 : 500,
              borderBottom: on ? "1.5px solid var(--accent)" : "1.5px solid transparent", paddingBottom: 2,
            }}>{s.l}</span>
            {i < 3 && <span style={{ width: 14, height: 1, background: "var(--line2)" }} />}
          </React.Fragment>
        );
      })}
    </div>
  );
}

/* ================================================================== *
 *  TEACHER — desktop-first workspace
 * ================================================================== */

function hwMeta(h) {
  const s = h.submission || {};
  if (h.status === "needs_review") {
    const bits = [];
    if (s.speaking) bits.push(`${s.speaking.duration} recording`);
    if (s.writing) bits.push(`${s.writing.words} words`);
    if (s.recall) bits.push(`${s.recall.confident} of ${s.recall.confident + s.recall.retry} recalled`);
    return { line: `Выполнено ${h.submittedLabel || "только что"}`, extra: bits.join(" · ") };
  }
  if (h.status === "in_progress") return { line: h.progressLabel || "Начал выполнять", extra: "" };
  if (h.status === "overdue") return { line: `Срок вышел: ${h.due}`, extra: "" };
  if (h.status === "feedback_sent") return { line: "Обратная связь отправлена", extra: "" };
  const t = h.tasks.reduce((a, x) => a + x.minutes, 0);
  return { line: `${h.tasks.length} tasks · ${t} min`, extra: `Due ${h.due}` };
}

function Avatar({ name, size = 36 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: 999, flexShrink: 0, background: "var(--soft)",
      color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center",
      fontWeight: 600, fontSize: size * 0.38, border: "1px solid #DCE7E2",
    }}>{name[0]}</div>
  );
}

function TeacherApp({ hw, setHw, notify, jumpToStudent }) {
  const [view, setView] = useState({ name: "home" });
  const narrow = useNarrow();
  const go = (name, id) => { setView({ name, id }); window.scrollTo?.(0, 0); };

  const NAV = [
    { k: "home", l: "Home", i: Home }, { k: "students", l: "Students", i: Users },
    { k: "homework", l: "Homework", i: ClipboardList }, { k: "materials", l: "Materials", i: BookOpen },
    { k: "settings", l: "Settings", i: Settings },
  ];
  const activeNav = ["student", "create"].includes(view.name) ? "students"
    : ["review", "results", "assigned"].includes(view.name) ? "homework" : view.name;

  const Sidebar = (
    <aside style={{
      width: 232, flexShrink: 0, borderRight: "1px solid var(--line)", padding: "22px 14px",
      display: "flex", flexDirection: "column", gap: 4, position: "sticky", top: 0, height: "100vh", background: "var(--bg)",
    }}>
      <div style={{ padding: "0 8px 20px" }}>
        <div className="el-serif" style={{ fontSize: 19 }}>English Loop</div>
        <div className="el-mono" style={{ fontSize: 10.5, color: "var(--ink3)", letterSpacing: ".1em", marginTop: 3 }}>CONCEPT B · PRACTICE LOOP</div>
      </div>
      {NAV.map((n) => (
        <button key={n.k} className={`el-nav ${activeNav === n.k ? "el-nav-on" : ""}`} onClick={() => go(n.k)}>
          <n.i size={16} strokeWidth={1.9} /> {n.l}
        </button>
      ))}
      <div style={{ marginTop: "auto", borderTop: "1px solid var(--line)", paddingTop: 14, display: "flex", gap: 10, alignItems: "center" }}>
        <Avatar name="Мария" size={32} />
        <div style={{ lineHeight: 1.3 }}>
          <div style={{ fontSize: 13.5, fontWeight: 550 }}>Мария К.</div>
          <div style={{ fontSize: 12, color: "var(--ink3)" }}>Частный преподаватель</div>
        </div>
      </div>
    </aside>
  );

  const MobileNav = (
    <nav style={{
      position: "sticky", bottom: 0, display: "flex", background: "rgba(250,249,246,.94)",
      backdropFilter: "blur(10px)", borderTop: "1px solid var(--line)", padding: "6px 4px calc(8px + env(safe-area-inset-bottom))", zIndex: 30,
    }}>
      {NAV.map((n) => (
        <button key={n.k} onClick={() => go(n.k)} style={{
          flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "6px 0",
          color: activeNav === n.k ? "var(--accent)" : "var(--ink3)", fontSize: 10.5, fontWeight: 550,
        }}><n.i size={18} strokeWidth={1.9} />{n.l}</button>
      ))}
    </nav>
  );

  let body = null;
  if (view.name === "home") body = <TeacherHome hw={hw} go={go} />;
  else if (view.name === "students") body = <TeacherStudents hw={hw} go={go} />;
  else if (view.name === "student") body = <StudentProfile id={view.id} hw={hw} go={go} />;
  else if (view.name === "create") body = <CreateHomework studentId={view.id} setHw={setHw} go={go} notify={notify} />;
  else if (view.name === "assigned") body = <AssignedDone hwId={view.id} hw={hw} go={go} jumpToStudent={jumpToStudent} />;
  else if (view.name === "review") body = <ReviewScreen hwId={view.id} hw={hw} setHw={setHw} go={go} notify={notify} />;
  else if (view.name === "results") body = <ResultsScreen hwId={view.id} hw={hw} go={go} notify={notify} />;
  else if (view.name === "homework") body = <HomeworkList hw={hw} go={go} />;
  else body = <Placeholder name={view.name} go={go} />;

  return (
    <div style={{ display: "flex", minHeight: "100vh", flexDirection: narrow ? "column" : "row" }}>
      {!narrow && Sidebar}
      <main className="el-scroll" style={{ flex: 1, minWidth: 0 }}>
        <div key={view.name + (view.id || "")} className="el-fade" style={{ padding: narrow ? "20px 16px 30px" : "34px 40px 60px", maxWidth: 1080, margin: "0 auto" }}>
          {narrow && view.name === "home" && (
            <div className="el-serif" style={{ fontSize: 17, marginBottom: 14 }}>English Loop</div>
          )}
          {body}
        </div>
      </main>
      {narrow && MobileNav}
    </div>
  );
}

/* ------------------------- Teacher: dashboard ------------------------- */

function TeacherHome({ hw, go }) {
  const list = Object.values(hw);
  const need = list.filter((h) => h.status === "needs_review");
  const soon = list.filter((h) => ["assigned", "in_progress"].includes(h.status));
  const late = list.filter((h) => h.status === "overdue");
  const done = list.filter((h) => h.status === "feedback_sent");
  const stats = [
    { n: need.length, l: "Needs review", c: "var(--amber)" },
    { n: soon.length, l: "In progress", c: "var(--ink)" },
    { n: late.length, l: "Overdue", c: "#9A4B3C" },
    { n: done.length, l: "Feedback sent", c: "var(--accent)" },
  ];

  const Row = ({ h }) => {
    const st = STUDENTS.find((s) => s.id === h.student);
    const m = hwMeta(h);
    const task = h.submission?.speaking ? "Speaking response" : h.tasks[0]?.title || h.title;
    return (
      <div className="el-card el-lift" style={{ padding: 16, display: "flex", gap: 14, alignItems: "center" }}>
        <Avatar name={st.name} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            <span style={{ fontWeight: 570, fontSize: 15 }}>{st.name}</span>
            <Pill status={h.status} />
          </div>
          <div style={{ color: "var(--ink2)", fontSize: 13.5, marginTop: 3 }}>{task}</div>
          <div className="el-mono" style={{ color: "var(--ink3)", fontSize: 12, marginTop: 4 }}>
            {m.line}{m.extra ? ` · ${m.extra}` : ""}
          </div>
        </div>
        {h.status === "needs_review" ? (
          <button className="el-btn el-p" onClick={() => go("review", h.id)}>Review</button>
        ) : h.status === "feedback_sent" ? (
          <button className="el-btn el-g" onClick={() => go("results", h.id)}>Results</button>
        ) : (
          <button className="el-btn el-g" onClick={() => go("student", h.student)}>Open student</button>
        )}
      </div>
    );
  };

  return (
    <>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 20, flexWrap: "wrap" }}>
        <div>
          <LoopRail stage={need.length ? "review" : "assign"} />
          <h1 className="el-serif" style={{ fontSize: 38, margin: "14px 0 6px" }}>Homework overview</h1>
          <p style={{ color: "var(--ink2)", margin: 0, fontSize: 15 }}>
            {need.length ? `${need.length} работы ждут проверки. Ближайшее занятие — четверг, 19:00.` : "Всё проверено. Ближайшее занятие — четверг, 19:00."}
          </p>
        </div>
        <button className="el-btn el-p" style={{ padding: "12px 20px" }} onClick={() => go("create", "ahav")}>
          <Plus size={16} strokeWidth={2.2} /> Create homework
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 12, margin: "26px 0 32px" }}>
        {stats.map((s) => (
          <div key={s.l} className="el-card" style={{ padding: "16px 18px" }}>
            <div className="el-mono el-serif" style={{ fontSize: 30, color: s.c, lineHeight: 1 }}>{s.n}</div>
            <div className="el-eyebrow" style={{ marginTop: 8 }}>{s.l}</div>
          </div>
        ))}
      </div>

      <Section title="Needs review" count={need.length} hint="Проверьте до подготовки следующего занятия">
        {need.length ? need.map((h) => <Row key={h.id} h={h} />) :
          <Empty text="Пусто. Как только ученик отправит работу, она появится здесь." />}
      </Section>

      <Section title="Due soon" count={soon.length}>
        {soon.length ? soon.map((h) => <Row key={h.id} h={h} />) : <Empty text="Нет активных заданий. Назначьте практику." />}
      </Section>

      {late.length > 0 && <Section title="Not started" count={late.length}>{late.map((h) => <Row key={h.id} h={h} />)}</Section>}
      {done.length > 0 && <Section title="Feedback sent" count={done.length}>{done.map((h) => <Row key={h.id} h={h} />)}</Section>}
    </>
  );
}

function Section({ title, count, hint, children }) {
  return (
    <section style={{ marginBottom: 32 }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: 12 }}>
        <h2 style={{ fontSize: 15.5, fontWeight: 600, margin: 0 }}>{title}</h2>
        {count !== undefined && <span className="el-mono" style={{ fontSize: 13, color: "var(--ink3)" }}>{count}</span>}
        {hint && <span style={{ fontSize: 12.5, color: "var(--ink3)", marginLeft: "auto" }}>{hint}</span>}
      </div>
      <div style={{ display: "grid", gap: 10 }}>{children}</div>
    </section>
  );
}

function Empty({ text }) {
  return <div className="el-card" style={{ padding: 20, color: "var(--ink3)", fontSize: 14, borderStyle: "dashed" }}>{text}</div>;
}

/* ------------------------- Teacher: students ------------------------- */

function TeacherStudents({ hw, go }) {
  return (
    <>
      <h1 className="el-serif" style={{ fontSize: 32, margin: "0 0 6px" }}>Students</h1>
      <p style={{ color: "var(--ink2)", marginTop: 0, marginBottom: 24 }}>Четыре ученика. Один профиль навыков, несколько направлений.</p>
      <div style={{ display: "grid", gap: 10 }}>
        {STUDENTS.map((s) => {
          const active = Object.values(hw).filter((h) => h.student === s.id);
          const need = active.filter((h) => h.status === "needs_review").length;
          return (
            <button key={s.id} className="el-card el-lift" onClick={() => go("student", s.id)}
              style={{ padding: 16, display: "flex", gap: 14, alignItems: "center", textAlign: "left" }}>
              <Avatar name={s.name} size={40} />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 570 }}>{s.name}</div>
                <div style={{ fontSize: 13, color: "var(--ink2)", marginTop: 2 }}>{s.tracks.join(" · ")} · {s.level}</div>
              </div>
              {need > 0 && <span className="el-pill" style={{ background: "var(--amber-s)", color: "var(--amber)" }}>{need} to review</span>}
              <span className="el-mono" style={{ fontSize: 12, color: "var(--ink3)" }}>{s.nextLesson}</span>
              <ChevronRight size={17} color="var(--ink3)" />
            </button>
          );
        })}
      </div>
    </>
  );
}

function StudentProfile({ id, hw, go }) {
  const s = STUDENTS.find((x) => x.id === id);
  const mine = Object.values(hw).filter((h) => h.student === id);
  const weak = ["look into", "carry out"];
  return (
    <>
      <button className="el-btn el-q" style={{ marginLeft: -10, marginBottom: 12 }} onClick={() => go("students")}>
        <ArrowLeft size={15} /> Students
      </button>
      <div style={{ display: "flex", gap: 18, alignItems: "center", flexWrap: "wrap" }}>
        <Avatar name={s.name} size={56} />
        <div style={{ flex: 1, minWidth: 200 }}>
          <h1 className="el-serif" style={{ fontSize: 34, margin: 0 }}>{s.name}</h1>
          <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap", alignItems: "center" }}>
            {s.tracks.map((t) => <span key={t} className="el-pill" style={{ background: "var(--sunk)", color: "var(--ink2)" }}>{t}</span>)}
            <span className="el-mono" style={{ fontSize: 12.5, color: "var(--ink3)" }}>{s.level} · с {s.since}</span>
          </div>
        </div>
        <button className="el-btn el-p" style={{ padding: "12px 20px" }} onClick={() => go("create", s.id)}>
          <Plus size={16} strokeWidth={2.2} /> Create homework
        </button>
      </div>

      <div className="el-card" style={{ padding: "14px 18px", margin: "22px 0", display: "flex", gap: 26, flexWrap: "wrap", alignItems: "center" }}>
        <div><div className="el-eyebrow">Следующее занятие</div><div className="el-mono" style={{ marginTop: 4, fontSize: 14 }}>{s.nextLesson}</div></div>
        <div><div className="el-eyebrow">Практика за 30 дней</div><div className="el-mono" style={{ marginTop: 4, fontSize: 14 }}>6 работ · 3 ч 12 мин</div></div>
        <div><div className="el-eyebrow">Активных выражений</div><div className="el-mono" style={{ marginTop: 4, fontSize: 14 }}>{EXPRESSIONS.length}</div></div>
      </div>

      <div style={{ display: "grid", gap: 20, gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))" }}>
        <div className="el-card" style={{ padding: 20 }}>
          <div className="el-eyebrow">English Core</div>
          <div style={{ marginTop: 14, display: "grid", gap: 12 }}>
            {CORE_SKILLS.map((k) => (
              <div key={k.s} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span style={{ width: 88, fontSize: 14 }}>{k.s}</span>
                <div style={{ display: "flex", gap: 4, flex: 1 }}>
                  {[1, 2, 3].map((i) => (
                    <span key={i} style={{
                      flex: 1, height: 4, borderRadius: 99,
                      background: i <= k.v ? (k.v === 1 ? "var(--amber)" : "var(--accent)") : "var(--line)",
                    }} />
                  ))}
                </div>
                <span style={{ fontSize: 12, color: "var(--ink3)", width: 108, textAlign: "right" }}>{SKILL_STATE[k.v - 1]}</span>
              </div>
            ))}
          </div>
          <div style={{ borderTop: "1px solid var(--line)", marginTop: 18, paddingTop: 14 }}>
            <div className="el-eyebrow">Exam track · IELTS</div>
            <div style={{ fontSize: 13.5, color: "var(--ink2)", marginTop: 6 }}>
              Writing Task 2 — структура аргумента ещё разваливается к третьему абзацу. Speaking Part 2 — держит минуту.
            </div>
          </div>
        </div>

        <div className="el-card" style={{ padding: 20 }}>
          <div className="el-eyebrow">Активные выражения</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 7, marginTop: 12 }}>
            {EXPRESSIONS.map((e) => (
              <span key={e} className="el-pill" style={{
                background: weak.includes(e) ? "var(--amber-s)" : "var(--sunk)",
                color: weak.includes(e) ? "var(--amber)" : "var(--ink2)", fontWeight: 500,
              }}>{e}</span>
            ))}
          </div>
          <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 12 }}>Подсвечены те, что пока не всплывают без подсказки.</div>
        </div>
      </div>

      <Section title="Homework" count={mine.length}>
        {mine.map((h) => {
          const m = hwMeta(h);
          return (
            <div key={h.id} className="el-card el-lift" style={{ padding: 15, display: "flex", gap: 14, alignItems: "center" }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <span style={{ fontWeight: 550, fontSize: 14.5 }}>{h.title}</span><Pill status={h.status} />
                </div>
                <div className="el-mono" style={{ fontSize: 12, color: "var(--ink3)", marginTop: 4 }}>{m.line}{m.extra ? ` · ${m.extra}` : ""}</div>
              </div>
              {h.status === "needs_review" && <button className="el-btn el-p" onClick={() => go("review", h.id)}>Review</button>}
              {h.status === "feedback_sent" && <button className="el-btn el-g" onClick={() => go("results", h.id)}>Results</button>}
            </div>
          );
        })}
      </Section>
    </>
  );
}

function HomeworkList({ hw, go }) {
  const list = Object.values(hw);
  return (
    <>
      <h1 className="el-serif" style={{ fontSize: 32, margin: "0 0 20px" }}>Homework</h1>
      <div style={{ display: "grid", gap: 10 }}>
        {list.map((h) => {
          const st = STUDENTS.find((s) => s.id === h.student);
          const m = hwMeta(h);
          return (
            <div key={h.id} className="el-card el-lift" style={{ padding: 15, display: "flex", gap: 14, alignItems: "center" }}>
              <Avatar name={st.name} size={34} />
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                  <span style={{ fontWeight: 550, fontSize: 14.5 }}>{st.name} · {h.title}</span><Pill status={h.status} />
                </div>
                <div className="el-mono" style={{ fontSize: 12, color: "var(--ink3)", marginTop: 4 }}>{m.line}{m.extra ? ` · ${m.extra}` : ""}</div>
              </div>
              {h.status === "needs_review" ? <button className="el-btn el-p" onClick={() => go("review", h.id)}>Review</button>
                : h.status === "feedback_sent" ? <button className="el-btn el-g" onClick={() => go("results", h.id)}>Results</button>
                  : <button className="el-btn el-g" onClick={() => go("student", h.student)}>Open</button>}
            </div>
          );
        })}
      </div>
    </>
  );
}

function Placeholder({ name, go }) {
  const copy = {
    materials: { t: "Materials", d: "Здесь лежат ваши материалы: списки выражений, промпты для Speaking, шаблоны Writing. В Concept B материал попадает в домашку в один клик.", b: "13 выражений · 8 speaking-промптов · 5 writing-заданий" },
    settings: { t: "Settings", d: "Расписание, напоминания ученикам, шаблоны обратной связи. В прототипе не подключено.", b: "Прототип · без backend" },
  }[name] || { t: name, d: "", b: "" };
  return (
    <>
      <h1 className="el-serif" style={{ fontSize: 32, margin: "0 0 8px" }}>{copy.t}</h1>
      <p style={{ color: "var(--ink2)", maxWidth: 520 }}>{copy.d}</p>
      <div className="el-card" style={{ padding: 20, marginTop: 16, borderStyle: "dashed", color: "var(--ink3)" }} >{copy.b}</div>
      <button className="el-btn el-g" style={{ marginTop: 18 }} onClick={() => go("home")}><ArrowLeft size={15} /> На главную</button>
    </>
  );
}

/* ------------------------- Teacher: create homework ------------------------- */

function CreateHomework({ studentId, setHw, go, notify }) {
  const s = STUDENTS.find((x) => x.id === studentId) || STUDENTS[0];
  const narrow = useNarrow(1000);
  const [goals, setGoals] = useState([GOALS[0], GOALS[1], GOALS[2]]);
  const [customGoal, setCustomGoal] = useState("");
  const [blocks, setBlocks] = useState(LIBRARY.map((b) => ({ ...b, key: b.id })));
  const [editing, setEditing] = useState(null);
  const [dueDay, setDueDay] = useState("Среда");
  const [dueTime, setDueTime] = useState("20:00");
  const [voice, setVoice] = useState(null);
  const [recording, setRecording] = useState(false);
  const [recSec, setRecSec] = useState(0);

  useEffect(() => {
    if (!recording) return;
    const t = setInterval(() => setRecSec((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, [recording]);

  const total = blocks.reduce((a, b) => a + b.minutes, 0);
  const toggleGoal = (g) => setGoals((x) => x.includes(g) ? x.filter((i) => i !== g) : [...x, g]);
  const move = (i, d) => setBlocks((b) => {
    const n = [...b], j = i + d;
    if (j < 0 || j >= n.length) return n;
    [n[i], n[j]] = [n[j], n[i]];
    return n;
  });
  const removeBlock = (k) => setBlocks((b) => b.filter((x) => x.key !== k));
  const addBlock = (id) => {
    const src = LIBRARY.find((l) => l.id === id);
    setBlocks((b) => [...b, { ...src, key: src.id + "-" + Date.now() }]);
  };
  const patch = (k, p) => setBlocks((b) => b.map((x) => x.key === k ? { ...x, ...p } : x));
  const missing = LIBRARY.filter((l) => !blocks.some((b) => b.type === l.type));

  const assign = () => {
    const id = "hw-" + s.id + "-" + Date.now();
    setHw((h) => {
      const next = { ...h };
      const oldThu = Object.values(h).find((x) => x.student === s.id && x.status === "assigned");
      if (oldThu) delete next[oldThu.id];
      next[id] = {
        id, student: s.id, title: "Practice before " + (s.nextLesson.split(",")[0]),
        status: "assigned", due: `${dueDay}, ${dueTime}`, nextLesson: s.nextLesson.split(",")[0],
        goals, tasks: blocks.map(({ key, ...b }) => b), voice, submission: {}, feedback: null, createdAt: Date.now(),
      };
      return next;
    });
    go("assigned", id);
  };

  const Summary = (
    <div className="el-card" style={{ padding: 20, position: narrow ? "static" : "sticky", top: 34 }}>
      <div className="el-eyebrow">Homework for {s.name}</div>
      <div style={{ marginTop: 14, display: "grid", gap: 9 }}>
        {blocks.map((b) => (
          <div key={b.key} style={{ display: "flex", justifyContent: "space-between", fontSize: 13.5, color: "var(--ink2)" }}>
            <span style={{ display: "flex", gap: 8, alignItems: "center" }}><TaskIcon name={b.icon} size={14} /> {b.title}</span>
            <span className="el-mono">{b.minutes} min</span>
          </div>
        ))}
        {!blocks.length && <div style={{ fontSize: 13, color: "var(--ink3)" }}>Добавьте хотя бы один блок.</div>}
      </div>
      <div style={{ borderTop: "1px solid var(--line)", margin: "16px 0 14px" }} />
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14 }}>
        <span>Estimated time</span><span className="el-mono" style={{ fontWeight: 600 }}>{total} min</span>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginTop: 6, color: "var(--ink2)" }}>
        <span>Due</span><span className="el-mono">{dueDay}, {dueTime}</span>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginTop: 6, color: "var(--ink2)" }}>
        <span>Goals</span><span className="el-mono">{goals.length}</span>
      </div>
      <button className="el-btn el-p" disabled={!blocks.length} onClick={assign}
        style={{ width: "100%", marginTop: 18, padding: "13px 18px", fontSize: 15 }}>
        Assign homework
      </button>
      <div style={{ fontSize: 12, color: "var(--ink3)", textAlign: "center", marginTop: 10 }}>
        {s.name} увидит {blocks.length} {blocks.length === 1 ? "задание" : "заданий"} в приложении.
      </div>
    </div>
  );

  return (
    <>
      <button className="el-btn el-q" style={{ marginLeft: -10, marginBottom: 10 }} onClick={() => go("student", s.id)}>
        <ArrowLeft size={15} /> {s.name}
      </button>
      <LoopRail stage="assign" />
      <h1 className="el-serif" style={{ fontSize: 34, margin: "14px 0 6px" }}>Create homework for {s.name}</h1>
      <p style={{ color: "var(--ink2)", marginTop: 0, marginBottom: 26 }}>
        Соберите практику за две минуты. Всё уже предзаполнено по прошлому занятию — правьте только то, что нужно.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: narrow ? "1fr" : "1fr 320px", gap: 26, alignItems: "start" }}>
        <div>
          <section style={{ marginBottom: 30 }}>
            <h2 style={{ fontSize: 15.5, fontWeight: 600, margin: "0 0 4px" }}>Goals for this homework</h2>
            <p style={{ fontSize: 13, color: "var(--ink3)", margin: "0 0 12px" }}>Цели видит и ученик — они же станут пунктами проверки.</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {GOALS.map((g) => (
                <button key={g} className={`el-chip ${goals.includes(g) ? "el-chip-on" : ""}`} onClick={() => toggleGoal(g)}>
                  {goals.includes(g) && <Check size={13} strokeWidth={2.6} />}{g}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 12, maxWidth: 460 }}>
              <input className="el-in" placeholder="Своя цель…" value={customGoal} onChange={(e) => setCustomGoal(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && customGoal.trim()) { setGoals((x) => [...x, customGoal.trim()]); setCustomGoal(""); } }} />
              <button className="el-btn el-g" disabled={!customGoal.trim()}
                onClick={() => { if (customGoal.trim()) { setGoals((x) => [...x, customGoal.trim()]); setCustomGoal(""); } }}>Добавить</button>
            </div>
          </section>

          <section style={{ marginBottom: 26 }}>
            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 12 }}>
              <h2 style={{ fontSize: 15.5, fontWeight: 600, margin: 0 }}>Tasks</h2>
              <span className="el-mono" style={{ fontSize: 12.5, color: "var(--ink3)" }}>{blocks.length} блока · {total} min</span>
            </div>
            <div style={{ display: "grid", gap: 12 }}>
              {blocks.map((b, i) => (
                <BlockCard key={b.key} b={b} i={i} last={i === blocks.length - 1}
                  open={editing === b.key} onToggle={() => setEditing(editing === b.key ? null : b.key)}
                  onMove={move} onRemove={removeBlock} patch={patch} />
              ))}
            </div>
            {missing.length > 0 && (
              <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap" }}>
                {missing.map((m) => (
                  <button key={m.id} className="el-chip" onClick={() => addBlock(m.id)}>
                    <Plus size={13} /> {m.title}
                  </button>
                ))}
              </div>
            )}
          </section>

          <section style={{ marginBottom: 26 }}>
            <h2 style={{ fontSize: 15.5, fontWeight: 600, margin: "0 0 12px" }}>Срок и голосовая инструкция</h2>
            <div className="el-card" style={{ padding: 18, display: "grid", gap: 16 }}>
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
                <Calendar size={16} color="var(--ink3)" />
                <select className="el-in" style={{ width: 150 }} value={dueDay} onChange={(e) => setDueDay(e.target.value)}>
                  {["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"].map((d) => <option key={d}>{d}</option>)}
                </select>
                <select className="el-in" style={{ width: 110 }} value={dueTime} onChange={(e) => setDueTime(e.target.value)}>
                  {["12:00", "18:00", "20:00", "22:00"].map((d) => <option key={d}>{d}</option>)}
                </select>
              </div>
              <div style={{ borderTop: "1px solid var(--line)", paddingTop: 14, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                {!voice && !recording && (
                  <button className="el-btn el-g" onClick={() => { setRecSec(0); setRecording(true); }}>
                    <Mic size={15} /> Записать голосовую инструкцию
                  </button>
                )}
                {recording && (
                  <button className="el-btn el-g el-rec" style={{ borderColor: "var(--amber)", color: "var(--amber)" }}
                    onClick={() => { setRecording(false); setVoice(mmss(recSec || 1)); }}>
                    <Square size={13} fill="currentColor" /> Стоп · <span className="el-mono">{mmss(recSec)}</span>
                  </button>
                )}
                {voice && (
                  <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    <span className="el-pill" style={{ background: "var(--soft)", color: "var(--accent)" }}>
                      <Volume2 size={13} /> Голосовая инструкция · <span className="el-mono">{voice}</span>
                    </span>
                    <button className="el-btn el-q" onClick={() => setVoice(null)}><Trash2 size={14} /></button>
                  </div>
                )}
                <span style={{ fontSize: 12.5, color: "var(--ink3)" }}>Симуляция записи — файл не создаётся.</span>
              </div>
            </div>
          </section>
        </div>
        {Summary}
      </div>
    </>
  );
}

function BlockCard({ b, i, last, open, onToggle, onMove, onRemove, patch }) {
  return (
    <div className="el-card" style={{ padding: 0, overflow: "hidden" }}>
      <div style={{ padding: 16, display: "flex", gap: 13, alignItems: "flex-start" }}>
        <div style={{
          width: 30, height: 30, borderRadius: 9, background: "var(--sunk)", display: "flex",
          alignItems: "center", justifyContent: "center", flexShrink: 0, color: "var(--ink2)",
        }}><TaskIcon name={b.icon} size={15} /></div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 560, fontSize: 14.5 }}>{b.title}</div>
          <div style={{ fontSize: 13, color: "var(--ink2)", marginTop: 2 }}>{b.prompt || b.subtitle}</div>
          <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 6, display: "flex", gap: 6, alignItems: "center" }}>
            <Sparkles size={12} /> {b.why}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 2 }}>
          <span className="el-mono" style={{ fontSize: 12.5, color: "var(--ink3)", marginRight: 6 }}>{b.minutes} min</span>
          <button className="el-btn el-q" title="Вверх" disabled={i === 0} onClick={() => onMove(i, -1)} style={{ opacity: i === 0 ? .3 : 1 }}><ArrowUp size={15} /></button>
          <button className="el-btn el-q" title="Вниз" disabled={last} onClick={() => onMove(i, 1)} style={{ opacity: last ? .3 : 1 }}><ArrowDown size={15} /></button>
          <button className="el-btn el-q" title="Изменить" onClick={onToggle}><Pencil size={14} /></button>
          <button className="el-btn el-q" title="Удалить" onClick={() => onRemove(b.key)}><Trash2 size={14} /></button>
        </div>
      </div>
      {open && (
        <div className="el-fadein" style={{ borderTop: "1px solid var(--line)", padding: 16, background: "var(--sunk)", display: "grid", gap: 14 }}>
          {b.prompt !== undefined && (
            <label style={{ display: "block" }}>
              <div className="el-eyebrow" style={{ marginBottom: 6 }}>Формулировка</div>
              <textarea className="el-ta" rows={2} value={b.prompt} onChange={(e) => patch(b.key, { prompt: e.target.value })} />
            </label>
          )}
          {b.type === "vocab" && (
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap", alignItems: "flex-end" }}>
              <label>
                <div className="el-eyebrow" style={{ marginBottom: 6 }}>Направление</div>
                <select className="el-in" style={{ width: 190 }} value={b.settings.direction}
                  onChange={(e) => patch(b.key, { settings: { ...b.settings, direction: e.target.value }, subtitle: `${e.target.value} · ${b.settings.count} expressions` })}>
                  <option>Russian → English</option><option>English → Russian</option>
                </select>
              </label>
              <label>
                <div className="el-eyebrow" style={{ marginBottom: 6 }}>Выражений: {b.settings.count}</div>
                <input type="range" min="4" max="13" value={b.settings.count} style={{ width: 190, accentColor: "var(--accent)" }}
                  onChange={(e) => { const c = +e.target.value; patch(b.key, { settings: { ...b.settings, count: c }, minutes: Math.max(4, Math.round(c * 0.9)), subtitle: `${b.settings.direction} · ${c} expressions` }); }} />
              </label>
            </div>
          )}
          {b.type === "speaking" && (
            <div>
              <div className="el-eyebrow" style={{ marginBottom: 6 }}>Try to use</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {b.targets.map((t) => <span key={t} className="el-pill" style={{ background: "#fff", color: "var(--ink2)", border: "1px solid var(--line)" }}>{t}</span>)}
              </div>
            </div>
          )}
          {b.type === "writing" && (
            <div>
              <div className="el-eyebrow" style={{ marginBottom: 6 }}>Requirements</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {b.reqs.map((t) => <span key={t} className="el-pill" style={{ background: "#fff", color: "var(--ink2)", border: "1px solid var(--line)" }}>{t}</span>)}
              </div>
            </div>
          )}
          {b.type === "grammar" && (
            <div>
              <div className="el-eyebrow" style={{ marginBottom: 6 }}>Focus</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {b.focus.map((t) => <span key={t} className="el-pill" style={{ background: "#fff", color: "var(--ink2)", border: "1px solid var(--line)" }}>{t}</span>)}
              </div>
            </div>
          )}
          <label style={{ maxWidth: 220 }}>
            <div className="el-eyebrow" style={{ marginBottom: 6 }}>Примерное время</div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <input type="range" min="3" max="30" value={b.minutes} style={{ flex: 1, accentColor: "var(--accent)" }}
                onChange={(e) => patch(b.key, { minutes: +e.target.value })} />
              <span className="el-mono" style={{ fontSize: 13 }}>{b.minutes} min</span>
            </div>
          </label>
          <div><button className="el-btn el-g" onClick={onToggle}>Готово</button></div>
        </div>
      )}
    </div>
  );
}

function AssignedDone({ hwId, hw, go, jumpToStudent }) {
  const h = hw[hwId];
  const s = STUDENTS.find((x) => x.id === h.student);
  return (
    <div className="el-pop" style={{ maxWidth: 520, margin: "8vh auto 0", textAlign: "center" }}>
      <div style={{
        width: 52, height: 52, borderRadius: 999, background: "var(--soft)", color: "var(--accent)",
        display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 22px",
      }}><Check size={24} strokeWidth={2.2} /></div>
      <h1 className="el-serif" style={{ fontSize: 32, margin: "0 0 10px" }}>Homework assigned</h1>
      <p style={{ color: "var(--ink2)", margin: "0 0 26px" }}>
        {s.name} увидит {h.tasks.length} сфокусированных задания. Срок — {h.due}.
      </p>
      <div className="el-card" style={{ padding: 18, textAlign: "left" }}>
        {h.tasks.map((t, i) => (
          <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", fontSize: 14, color: "var(--ink2)" }}>
            <span style={{ display: "flex", gap: 9, alignItems: "center" }}><TaskIcon name={t.icon} size={14} /> {t.title}</span>
            <span className="el-mono">{t.minutes} min</span>
          </div>
        ))}
        <div style={{ borderTop: "1px solid var(--line)", marginTop: 10, paddingTop: 10, display: "flex", justifyContent: "space-between", fontSize: 14 }}>
          <span>Estimated time</span>
          <span className="el-mono" style={{ fontWeight: 600 }}>{h.tasks.reduce((a, b) => a + b.minutes, 0)} min</span>
        </div>
      </div>
      <div style={{ display: "flex", gap: 10, justifyContent: "center", marginTop: 24, flexWrap: "wrap" }}>
        <button className="el-btn el-g" onClick={() => go("home")}>К дашборду</button>
        <button className="el-btn el-p" onClick={jumpToStudent}>Посмотреть глазами ученика <ChevronRight size={15} /></button>
      </div>
    </div>
  );
}

/* ------------------------- Teacher: review ------------------------- */

function Highlighted({ text, targets }) {
  const esc = (t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp("(" + targets.map(esc).join("|") + ")", "ig");
  const parts = String(text).split(re);
  return <>{parts.map((p, i) => targets.some((t) => norm(t) === norm(p))
    ? <span key={i} className="el-tg">{p}</span> : <span key={i}>{p}</span>)}</>;
}

const WAVE = Array.from({ length: 58 }, (_, i) => 0.22 + 0.78 * Math.abs(Math.sin(i * 1.61) * Math.cos(i * 0.37) + 0.25 * Math.sin(i * 0.9)));

function SpeakingReview({ sp, marks, setMarks }) {
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0);
  const [draft, setDraft] = useState(null);
  const [audioUrl, setAudioUrl] = useState(sp.audioUrl || null);
  const [audioError, setAudioError] = useState("");
  const audioRef = useRef(null);

  useEffect(() => {
    if (!sp.audioKey) return;
    let localUrl = null;
    let cancelled = false;
    loadAudioBlob(sp.audioKey).then((blob) => {
      if (cancelled || !blob) {
        if (!sp.audioUrl) setAudioError("The local audio recording is unavailable on this device.");
        return;
      }
      localUrl = URL.createObjectURL(blob);
      setAudioUrl(localUrl);
    }).catch(() => {
      if (!sp.audioUrl) setAudioError("The local audio recording is unavailable on this device.");
    });
    return () => {
      cancelled = true;
      if (localUrl) URL.revokeObjectURL(localUrl);
    };
  }, [sp.audioKey, sp.audioUrl]);

  useEffect(() => {
    if (!playing || audioUrl) return;
    const t = setInterval(() => setPos((p) => Math.min(1, p + 0.006)), 60);
    return () => clearInterval(t);
  }, [playing, audioUrl]);
  useEffect(() => { if (pos >= 1 && playing) setPlaying(false); }, [pos, playing]);
  const totalSec = sp.seconds || 124;
  const at = (f) => mmss(Math.round(f * totalSec));
  const togglePlayback = async () => {
    if (!audioUrl || !audioRef.current) {
      if (pos >= 1) setPos(0);
      setPlaying(!playing);
      return;
    }
    if (audioRef.current.paused) await audioRef.current.play();
    else audioRef.current.pause();
  };

  return (
    <div style={{ display: "grid", gap: 18 }}>
      <div className="el-card" style={{ padding: 18 }}>
        <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
          <button className="el-btn el-p" style={{ width: 44, height: 44, borderRadius: 999, padding: 0 }}
            onClick={togglePlayback} disabled={!!audioError}>
            {playing ? <Pause size={17} fill="#fff" /> : <Play size={17} fill="#fff" style={{ marginLeft: 2 }} />}
          </button>
          {audioUrl && <audio ref={audioRef} src={audioUrl} preload="metadata" playsInline
            onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => { setPlaying(false); setPos(1); }}
            onTimeUpdate={(e) => {
              const el = e.currentTarget;
              if (Number.isFinite(el.duration) && el.duration > 0) setPos(el.currentTime / el.duration);
            }} />}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 2, height: 42, cursor: "crosshair" }}
              onClick={(e) => {
                const r = e.currentTarget.getBoundingClientRect();
                const f = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
                if (audioRef.current && Number.isFinite(audioRef.current.duration)) audioRef.current.currentTime = f * audioRef.current.duration;
                setPos(f);
                setDraft({ at: f, text: "" });
              }}>
              {WAVE.map((h, i) => {
                const f = i / WAVE.length;
                return <span key={i} style={{
                  flex: 1, height: `${h * 100}%`, borderRadius: 2,
                  background: f <= pos ? "var(--accent)" : "#DFD9CD", transition: "background .1s",
                }} />;
              })}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 7 }}>
              <span className="el-mono" style={{ fontSize: 12, color: "var(--ink3)" }}>{at(pos)}</span>
              <span className="el-mono" style={{ fontSize: 12, color: "var(--ink3)" }}>{sp.duration}</span>
            </div>
          </div>
        </div>
        <div style={{ fontSize: 12.5, color: audioError ? "#9A4B3C" : "var(--ink3)", marginTop: 10 }}>
          {audioError || (audioUrl ? "Реальная запись ученика. Клик по дорожке — поставить пометку в конкретном месте." : "Демо-запись. Клик по дорожке — поставить пометку в конкретном месте.")}
        </div>
      </div>

      {(marks.length > 0 || draft) && (
        <div style={{ display: "grid", gap: 8 }}>
          {marks.map((m, i) => (
            <div key={i} className="el-card" style={{ padding: "12px 14px", display: "flex", gap: 12, alignItems: "flex-start", background: "var(--amber-s)", borderColor: "#EDDCC0" }}>
              <span className="el-mono" style={{ fontSize: 12, color: "var(--amber)", fontWeight: 600, marginTop: 2 }}>{at(m.at)}</span>
              <span style={{ flex: 1, fontSize: 13.5 }}>{m.text}</span>
              <button className="el-btn el-q" onClick={() => setMarks(marks.filter((_, j) => j !== i))}><X size={14} /></button>
            </div>
          ))}
          {draft && (
            <div className="el-card el-fadein" style={{ padding: 14 }}>
              <div className="el-eyebrow">Пометка на {at(draft.at)}</div>
              <textarea className="el-ta" rows={2} autoFocus placeholder="Что обсудить здесь на занятии…" style={{ marginTop: 8 }}
                value={draft.text} onChange={(e) => setDraft({ ...draft, text: e.target.value })} />
              <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                <button className="el-btn el-p" disabled={!draft.text.trim()}
                  onClick={() => { setMarks([...marks, draft].sort((a, b) => a.at - b.at)); setDraft(null); }}>Сохранить</button>
                <button className="el-btn el-q" onClick={() => setDraft(null)}>Отмена</button>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="el-card" style={{ padding: 18 }}>
        <div className="el-eyebrow">Target language</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 12 }}>
          {SPEAK_TARGETS.map((t) => {
            const on = (sp.used || []).includes(t);
            return (
              <span key={t} className="el-pill" style={{ background: on ? "var(--soft)" : "var(--sunk)", color: on ? "var(--accent)" : "var(--ink3)" }}>
                {on ? <Check size={13} strokeWidth={2.6} /> : <Circle size={11} />}{t}
              </span>
            );
          })}
        </div>
      </div>

      <div className="el-card" style={{ padding: 18 }}>
        <div className="el-eyebrow">Transcript</div>
        {sp.transcript ? (
          <p className="el-serif" style={{ fontSize: 17, lineHeight: 1.62, marginTop: 12, marginBottom: 0, color: "var(--ink)" }}>
            <Highlighted text={sp.transcript} targets={SPEAK_TARGETS.concat(["kept going"])} />
          </p>
        ) : (
          <p style={{ fontSize: 13.5, lineHeight: 1.55, margin: "10px 0 0", color: "var(--ink2)" }}>
            Automatic transcription is not enabled in this local prototype. Listen to the recording and leave feedback directly.
          </p>
        )}
      </div>
    </div>
  );
}

function WritingReview({ wr, notes, setNotes }) {
  const [open, setOpen] = useState(null);
  const custom = wr.text !== SAMPLE_ESSAY;
  return (
    <div style={{ display: "grid", gap: 18 }}>
      <div className="el-card" style={{ padding: "14px 18px", display: "flex", gap: 24, flexWrap: "wrap" }}>
        <div><div className="el-eyebrow">Слов</div><div className="el-mono" style={{ fontSize: 15, marginTop: 3 }}>{wr.words}</div></div>
        <div><div className="el-eyebrow">Target expressions</div><div className="el-mono" style={{ fontSize: 15, marginTop: 3 }}>{wr.used.length} из 6</div></div>
        <div><div className="el-eyebrow">Third Conditional</div><div className="el-mono" style={{ fontSize: 15, marginTop: 3 }}>{/had known|had looked|would have/i.test(wr.text) ? "есть" : "нет"}</div></div>
      </div>

      <div className="el-card" style={{ padding: 22 }}>
        <div className="el-eyebrow" style={{ marginBottom: 12 }}>Работа ученика</div>
        <p className="el-serif" style={{ fontSize: 17.5, lineHeight: 1.68, margin: 0 }}>
          {custom
            ? <Highlighted text={wr.text} targets={WRITE_TARGETS} />
            : ESSAY_PARTS.map((p, i) => {
              if (p.tag === "target") return <span key={i} className="el-tg">{p.t}</span>;
              if (p.tag === "fix" || p.tag === "good") {
                const on = notes.includes(p.id);
                return (
                  <span key={i} className={p.tag === "fix" ? "el-mark" : "el-mark-good"}
                    onClick={() => setOpen(open === p.id ? null : p.id)}
                    style={on ? { boxShadow: "0 0 0 2px rgba(143,99,32,.18)" } : undefined}>{p.t}</span>
                );
              }
              return <span key={i}>{p.t}</span>;
            })}
        </p>
        {custom && <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 14 }}>Это текст, который вы только что написали в режиме ученика.</div>}
        {!custom && <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 14 }}>Кликните по подсвеченному месту, чтобы приложить комментарий. Редактора документа здесь нет — только две-три пометки.</div>}
      </div>

      {open && (() => {
        const p = ESSAY_PARTS.find((x) => x.id === open);
        const on = notes.includes(open);
        return (
          <div className="el-card el-fadein" style={{ padding: 16 }}>
            <div className="el-eyebrow">{p.tag === "fix" ? "Что поправить" : "Что получилось"}</div>
            <div className="el-serif" style={{ fontSize: 15.5, margin: "8px 0 6px", color: "var(--ink2)" }}>«{p.t.slice(0, 70)}{p.t.length > 70 ? "…" : ""}»</div>
            <div style={{ fontSize: 14 }}>{p.note}</div>
            <button className="el-btn el-p" style={{ marginTop: 12 }}
              onClick={() => setNotes(on ? notes.filter((n) => n !== open) : [...notes, open])}>
              {on ? <><Check size={14} /> В обратной связи</> : "Добавить в обратную связь"}
            </button>
          </div>
        );
      })()}
    </div>
  );
}

function ReviewScreen({ hwId, hw, setHw, go, notify }) {
  const h = hw[hwId];
  const s = STUDENTS.find((x) => x.id === h.student);
  const narrow = useNarrow(1000);
  const sub = h.submission || {};
  const tabs = [
    sub.recall && { k: "recall", l: "Recall", i: "Languages" },
    sub.speaking && { k: "speaking", l: "Speaking", i: "Mic" },
    sub.writing && { k: "writing", l: "Writing", i: "PenLine" },
    sub.grammar && { k: "grammar", l: "Grammar", i: "Target" },
  ].filter(Boolean);
  const [tab, setTab] = useState(tabs[0]?.k);
  const [marks, setMarks] = useState([{ at: 0.26, text: "Речь встала на шесть секунд — на занятии потренируем короткие связки." }]);
  const [notes, setNotes] = useState([]);
  const [goalStates, setGoalStates] = useState(h.goals.map((_, i) => (i === 1 ? 2 : 1)));
  const [text, setText] = useState(
    "Good progress. Your speech was more continuous, and “eventually” appeared naturally. Next time, try to use “look into” and “carry out” without looking at the list."
  );
  const [voice, setVoice] = useState(null);
  const [rec, setRec] = useState(false);
  const [recSec, setRecSec] = useState(0);
  useEffect(() => { if (!rec) return; const t = setInterval(() => setRecSec((x) => x + 1), 1000); return () => clearInterval(t); }, [rec]);

  const send = () => {
    setHw((db) => ({ ...db, [hwId]: { ...db[hwId], status: "feedback_sent", feedback: { text, voice, goalStates, marks, notes } } }));
    notify("Feedback sent");
    go("results", hwId);
  };

  const Right = (
    <div style={{ display: "grid", gap: 16, position: narrow ? "static" : "sticky", top: 34 }}>
      <div className="el-card" style={{ padding: 18 }}>
        <div className="el-eyebrow">Goal review</div>
        <div style={{ display: "grid", gap: 14, marginTop: 14 }}>
          {h.goals.map((g, i) => (
            <div key={g}>
              <div style={{ fontSize: 13.5, marginBottom: 7 }}>{g}</div>
              <div style={{ display: "flex", gap: 4 }}>
                {["Needs practice", "Getting stronger", "Completed"].map((l, j) => (
                  <button key={l} className="el-btn" onClick={() => setGoalStates((x) => x.map((v, k) => k === i ? j : v))}
                    style={{
                      flex: 1, padding: "6px 4px", fontSize: 11.5, borderRadius: 9,
                      background: goalStates[i] === j ? (j === 0 ? "var(--amber-s)" : "var(--soft)") : "var(--sunk)",
                      color: goalStates[i] === j ? (j === 0 ? "var(--amber)" : "var(--accent)") : "var(--ink3)",
                      fontWeight: goalStates[i] === j ? 600 : 500,
                    }}>{l}</button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="el-card" style={{ padding: 18 }}>
        <div className="el-eyebrow">Teacher feedback</div>
        <textarea className="el-ta" rows={6} style={{ marginTop: 10 }} value={text} onChange={(e) => setText(e.target.value)} />
        <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center", flexWrap: "wrap" }}>
          {!voice && !rec && <button className="el-btn el-g" onClick={() => { setRecSec(0); setRec(true); }}><Mic size={14} /> Голосовой комментарий</button>}
          {rec && <button className="el-btn el-g el-rec" style={{ borderColor: "var(--amber)", color: "var(--amber)" }}
            onClick={() => { setRec(false); setVoice(mmss(recSec || 1)); }}><Square size={12} fill="currentColor" /> Стоп · <span className="el-mono">{mmss(recSec)}</span></button>}
          {voice && <>
            <span className="el-pill" style={{ background: "var(--soft)", color: "var(--accent)" }}><Volume2 size={13} /> <span className="el-mono">{voice}</span></span>
            <button className="el-btn el-q" onClick={() => setVoice(null)}><Trash2 size={14} /></button>
          </>}
        </div>
        {(notes.length > 0 || marks.length > 0) && (
          <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 12 }}>
            К обратной связи приложено: {marks.length} пометок в записи, {notes.length} в тексте.
          </div>
        )}
        <button className="el-btn el-p" style={{ width: "100%", marginTop: 14, padding: "12px" }} onClick={send}>
          <Send size={15} /> Send feedback
        </button>
      </div>
    </div>
  );

  return (
    <>
      <button className="el-btn el-q" style={{ marginLeft: -10, marginBottom: 10 }} onClick={() => go("home")}><ArrowLeft size={15} /> Homework overview</button>
      <LoopRail stage="review" />
      <div style={{ display: "flex", gap: 14, alignItems: "center", margin: "14px 0 4px" }}>
        <Avatar name={s.name} size={44} />
        <h1 className="el-serif" style={{ fontSize: 32, margin: 0 }}>Review {s.name}’s homework</h1>
      </div>
      <p style={{ color: "var(--ink2)", marginTop: 0 }}>
        {h.title} · выполнено {h.submittedLabel || "только что"} · всего практики <span className="el-mono">{h.totalTime || 34} мин</span>
      </p>

      <div style={{ display: "flex", gap: 6, margin: "22px 0 20px", flexWrap: "wrap" }}>
        {tabs.map((t) => (
          <button key={t.k} className="el-chip" onClick={() => setTab(t.k)}
            style={tab === t.k ? { background: "var(--ink)", borderColor: "var(--ink)", color: "#fff" } : undefined}>
            <TaskIcon name={t.i} size={14} /> {t.l}
          </button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: narrow ? "1fr" : "1fr 330px", gap: 26, alignItems: "start" }}>
        <div key={tab} className="el-fade">
          {tab === "speaking" && <SpeakingReview sp={sub.speaking} marks={marks} setMarks={setMarks} />}
          {tab === "writing" && <WritingReview wr={sub.writing} notes={notes} setNotes={setNotes} />}
          {tab === "recall" && (
            <div className="el-card" style={{ padding: 20 }}>
              <div className="el-eyebrow">Vocabulary Recall</div>
              <div style={{ display: "flex", gap: 26, marginTop: 14 }}>
                <div><div className="el-serif el-mono" style={{ fontSize: 28, color: "var(--accent)" }}>{sub.recall.confident}</div><div style={{ fontSize: 12.5, color: "var(--ink3)" }}>уверенно</div></div>
                <div><div className="el-serif el-mono" style={{ fontSize: 28, color: "var(--amber)" }}>{sub.recall.retry}</div><div style={{ fontSize: 12.5, color: "var(--ink3)" }}>со второй попытки</div></div>
              </div>
              <div style={{ borderTop: "1px solid var(--line)", marginTop: 16, paddingTop: 14 }}>
                <div className="el-eyebrow" style={{ marginBottom: 8 }}>Вернуть в активный recall</div>
                <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
                  {(sub.recall.retryItems || []).map((t) => <span key={t} className="el-pill" style={{ background: "var(--amber-s)", color: "var(--amber)" }}>{t}</span>)}
                </div>
              </div>
            </div>
          )}
          {tab === "grammar" && (
            <div className="el-card" style={{ padding: 20 }}>
              <div className="el-eyebrow">Grammar in Context</div>
              <div className="el-serif el-mono" style={{ fontSize: 28, marginTop: 12 }}>{sub.grammar.correct} / {sub.grammar.total}</div>
              <div style={{ fontSize: 13.5, color: "var(--ink2)", marginTop: 10 }}>
                Слабое место: {(sub.grammar.missed || []).join(", ") || "нет"}. Стоит вернуть в следующее занятие короткой разминкой.
              </div>
            </div>
          )}
        </div>
        {Right}
      </div>
    </>
  );
}

/* ------------------------- Teacher: results ------------------------- */

function ResultsScreen({ hwId, hw, go, notify }) {
  const h = hw[hwId];
  const s = STUDENTS.find((x) => x.id === h.student);
  const [added, setAdded] = useState(false);
  const sub = h.submission || {};
  const doneCount = Object.keys(sub).length;
  const stronger = ["eventually", "speaking continuity", "Third Conditional"];
  const practice = ["look into", "carry out", "articles", "spontaneous sentence structure"];
  const plan = [
    "Начать с двухминутного спонтанного Speaking",
    "Вернуть «look into» и «carry out» в активный recall",
    "Разобрать две ошибки из Writing",
    "Не повторять выражения, которые уже уверенные",
  ];
  return (
    <>
      <button className="el-btn el-q" style={{ marginLeft: -10, marginBottom: 10 }} onClick={() => go("home")}><ArrowLeft size={15} /> Homework overview</button>
      <LoopRail stage={added ? "lesson" : "review"} />
      <h1 className="el-serif" style={{ fontSize: 34, margin: "14px 0 6px" }}>{s.name}’s homework</h1>
      <p style={{ color: "var(--ink2)", marginTop: 0 }}>
        Completed: <span className="el-mono">{doneCount} of {h.tasks.length}</span> · Total practice time: <span className="el-mono">{h.totalTime || 34} min</span>
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(260px,1fr))", gap: 14, margin: "24px 0" }}>
        <div className="el-card" style={{ padding: 20 }}>
          <div className="el-eyebrow" style={{ color: "var(--accent)" }}>Getting stronger</div>
          <div style={{ display: "grid", gap: 9, marginTop: 14 }}>
            {stronger.map((t) => <div key={t} style={{ display: "flex", gap: 9, alignItems: "center", fontSize: 14.5 }}>
              <CheckCircle2 size={15} color="var(--accent)" /> {t}</div>)}
          </div>
        </div>
        <div className="el-card" style={{ padding: 20 }}>
          <div className="el-eyebrow" style={{ color: "var(--amber)" }}>Needs practice</div>
          <div style={{ display: "grid", gap: 9, marginTop: 14 }}>
            {practice.map((t) => <div key={t} style={{ display: "flex", gap: 9, alignItems: "center", fontSize: 14.5 }}>
              <Circle size={13} color="var(--amber)" /> {t}</div>)}
          </div>
        </div>
      </div>

      <div className="el-card" style={{ padding: 22, borderColor: added ? "#CFE0D9" : "var(--line)", background: added ? "var(--soft)" : "#fff" }}>
        <div className="el-eyebrow">Recommendation for {s.nextLesson.split(",")[0]}</div>
        <div style={{ display: "grid", gap: 10, marginTop: 14 }}>
          {plan.map((p, i) => (
            <div key={p} style={{ display: "flex", gap: 12, fontSize: 15 }}>
              <span className="el-mono" style={{ color: "var(--ink3)", fontSize: 12.5, paddingTop: 3 }}>{String(i + 1).padStart(2, "0")}</span>
              <span>{p}</span>
            </div>
          ))}
        </div>
        <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 14 }}>Черновик рекомендации на mock-данных, без AI-бэкенда.</div>
        {!added ? (
          <button className="el-btn el-p" style={{ marginTop: 18, padding: "12px 20px" }}
            onClick={() => { setAdded(true); notify("Added to Thursday’s lesson"); }}>
            Add results to next lesson
          </button>
        ) : (
          <div className="el-pop" style={{ marginTop: 18, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
            <span className="el-pill" style={{ background: "#fff", color: "var(--accent)" }}><Check size={13} strokeWidth={2.6} /> В плане занятия {s.nextLesson}</span>
            <button className="el-btn el-g" onClick={() => go("create", s.id)}>Собрать следующую практику</button>
          </div>
        )}
      </div>
    </>
  );
}

/* ================================================================== *
 *  STUDENT — mobile-first practice
 * ================================================================== */

function StudentApp({ hw, setHw, notify, jumpToTeacher }) {
  const narrow = useNarrow(940);
  const [tab, setTab] = useState("today");
  const [run, setRun] = useState(null);
  const [progressByHomework, setProgressByHomework] = useState({});

  const candidates = Object.values(hw)
    .filter((h) => h.student === "ahav" && ["assigned", "in_progress", "submitted", "needs_review"].includes(h.status))
    .sort((a, b) => {
      const priority = { assigned: 4, in_progress: 3, submitted: 2, needs_review: 1 };
      const statusDiff = (priority[b.status] || 0) - (priority[a.status] || 0);
      return statusDiff || (b.createdAt || 0) - (a.createdAt || 0);
    });
  const active = candidates[0];
  const withFb = Object.values(hw).find((h) => h.student === "ahav" && h.feedback);
  const savedProgress = active ? {
    vocab: active.submission?.recall,
    speaking: active.submission?.speaking,
    writing: active.submission?.writing,
    grammar: active.submission?.grammar,
  } : {};
  const progress = active ? { ...savedProgress, ...(progressByHomework[active.id] || {}) } : {};

  const finish = (type, data) => {
    if (!active) return;
    setProgressByHomework((all) => ({
      ...all,
      [active.id]: { ...(all[active.id] || {}), [type]: data },
    }));
    setRun(null);
    const submissionKey = type === "vocab" ? "recall" : type;
    setHw((db) => {
      const current = db[active.id];
      const status = type === "speaking" ? "needs_review"
        : current.status === "assigned" ? "in_progress" : current.status;
      return {
        ...db,
        [active.id]: {
          ...current,
          status,
          submission: { ...(current.submission || {}), [submissionKey]: data },
          ...(type === "speaking" ? { submittedLabel: "только что" } : {}),
        },
      };
    });
  };

  const submitAll = () => {
    if (!active) return;
    const sub = { ...(active.submission || {}) };
    if (progress.vocab) sub.recall = progress.vocab;
    if (progress.speaking) sub.speaking = progress.speaking;
    if (progress.writing) sub.writing = progress.writing;
    if (progress.grammar) sub.grammar = progress.grammar;
    const mins = active.tasks.reduce((a, b) => a + b.minutes, 0);
    setHw((db) => ({ ...db, [active.id]: { ...db[active.id], status: "needs_review", submission: sub, submittedLabel: "только что", totalTime: mins } }));
    notify("Homework submitted");
    setTab("today");
  };

  let screen;
  if (run) {
    const props = { task: run, onExit: () => setRun(null), onDone: finish, notify };
    screen = run.type === "vocab" ? <RecallRunner {...props} />
      : run.type === "speaking" ? <SpeakingRunner {...props} />
        : run.type === "writing" ? <WritingRunner {...props} />
          : <GrammarRunner {...props} />;
  } else if (tab === "today") {
    screen = <StudentToday hw={active} progress={progress} setRun={setRun} submitAll={submitAll} feedbackHw={withFb} openFeedback={() => setTab("feedback")} />;
  } else if (tab === "practice") {
    screen = <StudentPractice hw={hw} setRun={setRun} progress={progress} active={active} />;
  } else if (tab === "feedback") {
    screen = <StudentFeedback h={withFb} setRun={setRun} jumpToTeacher={jumpToTeacher} />;
  } else {
    screen = <StudentProgress />;
  }

  const TABS = [
    { k: "today", l: "Today", i: Home }, { k: "practice", l: "Practice", i: ClipboardList },
    { k: "feedback", l: "Feedback", i: MessageSquare }, { k: "progress", l: "Progress", i: TrendingUp },
  ];

  const inner = (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg)" }}>
      <div className="el-mono" style={{
        display: "flex", justifyContent: "space-between", padding: "12px 22px 6px",
        fontSize: 12, color: "var(--ink3)", flexShrink: 0,
      }}>
        <span>19:42</span><span>English Loop</span>
      </div>
      <div className="el-scroll" key={tab + (run?.id || "")} style={{ flex: 1, minHeight: 0 }}>
        <div className="el-fade" style={{ padding: "6px 22px 28px" }}>{screen}</div>
      </div>
      {!run && (
        <nav style={{
          display: "flex", borderTop: "1px solid var(--line)", background: "rgba(250,249,246,.95)",
          backdropFilter: "blur(10px)", padding: "7px 6px calc(10px + env(safe-area-inset-bottom))", flexShrink: 0,
        }}>
          {TABS.map((t) => {
            const on = tab === t.k;
            const dot = t.k === "feedback" && withFb && withFb.feedback;
            return (
              <button key={t.k} onClick={() => setTab(t.k)} style={{
                flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4,
                padding: "5px 0", color: on ? "var(--accent)" : "var(--ink3)", fontSize: 10.5, fontWeight: 550,
              }}>
                <span style={{ position: "relative" }}>
                  <t.i size={19} strokeWidth={on ? 2.1 : 1.8} />
                  {dot && <span style={{ position: "absolute", top: -1, right: -3, width: 7, height: 7, borderRadius: 99, background: "var(--amber)" }} />}
                </span>
                {t.l}
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );

  if (narrow) return <div style={{ height: "calc(100dvh - 51px - env(safe-area-inset-top))", display: "flex", flexDirection: "column" }}>{inner}</div>;
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", gap: 46, padding: "40px 20px", flexWrap: "wrap" }}>
      <div style={{ maxWidth: 330 }}>
        <div className="el-eyebrow">Student practice</div>
        <h2 className="el-serif" style={{ fontSize: 30, margin: "12px 0 12px" }}>Приложение ученика</h2>
        <p style={{ color: "var(--ink2)", fontSize: 14.5, lineHeight: 1.65 }}>
          Ученик не видит ни курсов, ни матрицы навыков, ни экзаменационных треков — только сегодняшнюю практику,
          цели этой практики и ответ преподавателя.
        </p>
        <p style={{ color: "var(--ink3)", fontSize: 13.5, lineHeight: 1.6 }}>
          Начните с <b style={{ color: "var(--ink2)" }}>Start practice</b>: Recall → Speaking → Writing → Grammar → Submit homework.
          Затем вернитесь в режим преподавателя и проверьте работу.
        </p>
        <button className="el-btn el-g" style={{ marginTop: 6 }} onClick={jumpToTeacher}>
          <ArrowLeft size={15} /> В режим преподавателя
        </button>
      </div>
      <div className="el-phone" style={{ height: 748 }}>{inner}</div>
    </div>
  );
}

/* ------------------------- Student: today ------------------------- */

function StudentToday({ hw, progress, setRun, submitAll, feedbackHw, openFeedback }) {
  if (!hw) return (
    <div style={{ paddingTop: 40, textAlign: "center" }}>
      <div className="el-serif" style={{ fontSize: 24, marginBottom: 8 }}>Практики пока нет</div>
      <p style={{ color: "var(--ink2)", fontSize: 14 }}>Как только преподаватель назначит задание, оно появится здесь.</p>
    </div>
  );
  const total = hw.tasks.reduce((a, b) => a + b.minutes, 0);
  const doneCount = hw.tasks.filter((t) => progress[t.type]).length;
  const allDone = doneCount === hw.tasks.length;
  const submitted = allDone && ["needs_review", "submitted", "feedback_sent"].includes(hw.status);
  const speakingSent = !!hw.submission?.speaking && !submitted;
  const nextTask = hw.tasks.find((t) => !progress[t.type]);

  return (
    <>
      <div style={{ fontSize: 14, color: "var(--ink2)", marginTop: 10 }}>Good evening, Ahav</div>
      <h1 className="el-serif" style={{ fontSize: 30, margin: "6px 0 10px", lineHeight: 1.15 }}>
        {submitted ? "Practice submitted" : `Practice before ${hw.nextLesson || "Thursday"}`}
      </h1>
      <div className="el-mono" style={{ fontSize: 13, color: "var(--ink3)" }}>
        {hw.tasks.length} focused tasks · ≈{total} минут
      </div>

      {feedbackHw && feedbackHw.feedback && (
        <button className="el-card el-pop" onClick={openFeedback} style={{
          width: "100%", textAlign: "left", padding: 16, marginTop: 18, background: "var(--soft)", borderColor: "#CFE0D9",
        }}>
          <div className="el-eyebrow" style={{ color: "var(--accent)" }}>Feedback from your teacher</div>
          <div style={{ fontSize: 14, marginTop: 9, lineHeight: 1.5 }}>
            <b style={{ fontWeight: 600 }}>Speaking.</b> Good progress — your answer was more continuous.<br />
            <b style={{ fontWeight: 600 }}>Writing.</b> Two sentences to review.
          </div>
          <div className="el-btn el-p" style={{ marginTop: 13, width: "100%" }}>View feedback</div>
        </button>
      )}

      <div className="el-card" style={{ padding: 16, marginTop: 18 }}>
        <div className="el-eyebrow">Your goals</div>
        <div style={{ display: "grid", gap: 8, marginTop: 11 }}>
          {hw.goals.slice(0, 3).map((g) => (
            <div key={g} style={{ display: "flex", gap: 9, fontSize: 14, alignItems: "flex-start" }}>
              <Target size={14} color="var(--accent)" style={{ marginTop: 3, flexShrink: 0 }} />{g}
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: "grid", gap: 10, marginTop: 18 }}>
        {hw.tasks.map((t, i) => {
          const done = !!progress[t.type];
          return (
            <button key={i} className="el-card el-lift" onClick={() => setRun(t)} style={{ padding: 15, display: "flex", gap: 14, alignItems: "center", textAlign: "left" }}>
              <span className="el-mono" style={{ fontSize: 12, color: done ? "var(--accent)" : "var(--ink3)", width: 18 }}>
                {done ? <Check size={15} strokeWidth={2.6} /> : String(i + 1).padStart(2, "0")}
              </span>
              <span style={{ flex: 1, minWidth: 0 }}>
                <span style={{ display: "block", fontWeight: 560, fontSize: 15 }}>{t.title}</span>
                <span style={{ display: "block", fontSize: 13, color: "var(--ink2)", marginTop: 2 }}>
                  {t.type === "speaking" ? "A demanding day" : t.type === "writing" ? "Changed plans" : t.type === "grammar" ? "Third Conditional" : `${t.settings?.count || 8} expressions`} · {t.minutes} min
                </span>
              </span>
              <ChevronRight size={17} color="var(--ink3)" />
            </button>
          );
        })}
      </div>

      {speakingSent && (
        <div className="el-card el-fadein" style={{ padding: 14, marginTop: 14, background: "var(--soft)", borderColor: "#CFE0D9" }}>
          <div style={{ fontSize: 14, fontWeight: 560, color: "var(--accent)" }}>Speaking sent to your teacher</div>
          <div style={{ fontSize: 12.5, color: "var(--ink2)", marginTop: 4 }}>Можно продолжить остальные задания. Запись уже доступна преподавателю.</div>
        </div>
      )}

      {!submitted && (
        <button className="el-btn el-p" style={{ width: "100%", marginTop: 20, padding: "15px", fontSize: 16, borderRadius: 13 }}
          onClick={() => allDone ? submitAll() : setRun(nextTask)}>
          {allDone ? "Submit homework" : doneCount ? "Continue practice" : "Start practice"}
        </button>
      )}
      {submitted && (
        <div className="el-card" style={{ padding: 16, marginTop: 20, textAlign: "center" }}>
          <div style={{ fontSize: 14.5, fontWeight: 550 }}>Отправлено преподавателю</div>
          <div style={{ fontSize: 13, color: "var(--ink2)", marginTop: 5 }}>Обратная связь появится здесь и во вкладке Feedback.</div>
        </div>
      )}

      <div style={{ textAlign: "center", marginTop: 16, fontSize: 13, color: "var(--ink3)" }}>
        <div className="el-mono">Due {hw.due}</div>
        {!submitted && <div style={{ marginTop: 4 }}>Teacher feedback will appear here.</div>}
      </div>
      {hw.voice && (
        <div className="el-card" style={{ padding: 13, marginTop: 14, display: "flex", gap: 10, alignItems: "center" }}>
          <Volume2 size={16} color="var(--accent)" />
          <span style={{ fontSize: 13.5, flex: 1 }}>Голосовая инструкция преподавателя</span>
          <span className="el-mono" style={{ fontSize: 12.5, color: "var(--ink3)" }}>{hw.voice}</span>
        </div>
      )}
    </>
  );
}

function ExerciseHeader({ title, sub, onExit, step, of }) {
  return (
    <div style={{ paddingTop: 6, marginBottom: 20 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginLeft: -8 }}>
        <button className="el-btn el-q" onClick={onExit}><ArrowLeft size={17} /></button>
        <span style={{ fontSize: 14, fontWeight: 560 }}>{title}</span>
        {step && <span className="el-mono" style={{ marginLeft: "auto", fontSize: 12.5, color: "var(--ink3)" }}>{step} / {of}</span>}
      </div>
      {of && <div className="el-bar" style={{ marginTop: 12 }}><span style={{ width: `${(step / of) * 100}%` }} /></div>}
      {sub && <div style={{ fontSize: 13, color: "var(--ink3)", marginTop: 10 }}>{sub}</div>}
    </div>
  );
}

/* ------------------------- Student: Recall ------------------------- */

function RecallRunner({ task, onExit, onDone }) {
  const n = Math.min(task.settings?.count || 8, RECALL_ITEMS.length);
  const items = RECALL_ITEMS.slice(0, n);
  const [i, setI] = useState(0);
  const [val, setVal] = useState("");
  const [state, setState] = useState(null); // null | 'ok' | 'almost'
  const [conf, setConf] = useState(0);
  const [retry, setRetry] = useState([]);
  const [tried, setTried] = useState(false);
  const [listening, setListening] = useState(false);
  const [fin, setFin] = useState(false);

  const it = items[i];
  const check = () => {
    const ok = it.key.every((k) => norm(val).includes(norm(k)));
    setState(ok ? "ok" : "almost");
    if (ok && !tried) setConf((c) => c + 1);
    if (!ok && !tried) { setRetry((r) => [...r, it.key[0]]); setTried(true); }
  };
  const next = () => {
    if (i + 1 >= items.length) setFin(true);
    else { setI(i + 1); setVal(""); setState(null); setTried(false); }
  };
  const speak = () => {
    setListening(true);
    setTimeout(() => { setListening(false); setVal(it.en.replace(/^(\w)/, (m) => m.toLowerCase()).replace(/\.$/, "")); }, 1300);
  };

  if (fin) return (
    <div className="el-fade" style={{ paddingTop: 30 }}>
      <div className="el-eyebrow">Vocabulary Recall</div>
      <h2 className="el-serif" style={{ fontSize: 28, margin: "10px 0 22px" }}>Recall completed</h2>
      <div className="el-card" style={{ padding: 20, display: "flex", gap: 26 }}>
        <div><div className="el-serif el-mono" style={{ fontSize: 30, color: "var(--accent)" }}>{conf}</div>
          <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 2 }}>recalled confidently</div></div>
        <div><div className="el-serif el-mono" style={{ fontSize: 30, color: "var(--amber)" }}>{items.length - conf}</div>
          <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 2 }}>need another attempt</div></div>
      </div>
      {retry.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <div className="el-eyebrow" style={{ marginBottom: 9 }}>Вернём в следующую практику</div>
          <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
            {retry.map((t, k) => <span key={k} className="el-pill" style={{ background: "var(--amber-s)", color: "var(--amber)" }}>{t}</span>)}
          </div>
        </div>
      )}
      <button className="el-btn el-p" style={{ width: "100%", marginTop: 24, padding: 14, fontSize: 15 }}
        onClick={() => onDone("vocab", { confident: conf, retry: items.length - conf, retryItems: retry })}>
        Continue
      </button>
    </div>
  );

  return (
    <>
      <ExerciseHeader title="Vocabulary Recall" onExit={onExit} step={i + 1} of={items.length} />
      <div className="el-eyebrow">Translate into English</div>
      <p className="el-serif" style={{ fontSize: 23, lineHeight: 1.35, margin: "14px 0 22px" }}>«{it.ru}»</p>

      <textarea className="el-ta" rows={3} placeholder="Ваш ответ…" value={val} disabled={!!state}
        onChange={(e) => setVal(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && val.trim()) { e.preventDefault(); check(); } }} />

      {!state && (
        <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
          <button className="el-btn el-g" onClick={speak} style={listening ? { borderColor: "var(--amber)", color: "var(--amber)" } : undefined}>
            <Mic size={15} /> {listening ? "Слушаю…" : "Speak answer"}
          </button>
          <button className="el-btn el-p" style={{ flex: 1 }} disabled={!val.trim()} onClick={check}>Check</button>
        </div>
      )}

      {state && (
        <div className="el-card el-fadein" style={{
          padding: 18, marginTop: 16,
          background: state === "ok" ? "var(--soft)" : "var(--amber-s)",
          borderColor: state === "ok" ? "#CFE0D9" : "#EDDCC0",
        }}>
          <div style={{ fontWeight: 600, fontSize: 15, color: state === "ok" ? "var(--accent)" : "var(--amber)" }}>
            {state === "ok" ? "Exactly right" : "Almost there"}
          </div>
          <p className="el-serif" style={{ fontSize: 17, lineHeight: 1.5, margin: "10px 0 0" }}>{it.en}</p>
          <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
            <button className="el-btn el-p" style={{ flex: 1 }} onClick={next}>Got it</button>
            {state === "almost" && (
              <button className="el-btn el-g" onClick={() => { setState(null); setVal(""); }}>Try again</button>
            )}
          </div>
        </div>
      )}
    </>
  );
}

/* ------------------------- Student: Speaking ------------------------- */

function SpeakingRunner({ task, onExit, onDone }) {
  const [sec, setSec] = useState(0);
  const [phase, setPhase] = useState("idle"); // idle | requesting | recording | processing | ready
  const [audioUrl, setAudioUrl] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [error, setError] = useState("");
  const recorderRef = useRef(null);
  const streamRef = useRef(null);
  const chunksRef = useRef([]);
  const blobRef = useRef(null);
  const startRef = useRef(0);
  const audioRef = useRef(null);

  useEffect(() => {
    if (phase !== "recording") return;
    const t = setInterval(() => setSec(Math.max(0, Math.round((Date.now() - startRef.current) / 1000))), 250);
    return () => clearInterval(t);
  }, [phase]);

  useEffect(() => () => {
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
    streamRef.current?.getTracks().forEach((track) => track.stop());
  }, []);

  const start = async () => {
    setError("");
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      setError("This browser cannot record audio. Open the demo in Safari 14.5 or later over HTTPS.");
      return;
    }
    setPhase("requesting");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      const mimeType = speakingMimeType();
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      chunksRef.current = [];
      streamRef.current = stream;
      recorderRef.current = recorder;
      recorder.ondataavailable = (event) => { if (event.data?.size) chunksRef.current.push(event.data); };
      recorder.onerror = () => {
        setError("The recording stopped unexpectedly. Please try again.");
        setPhase("idle");
        stream.getTracks().forEach((track) => track.stop());
      };
      recorder.onstop = () => {
        const seconds = Math.max(1, Math.round((Date.now() - startRef.current) / 1000));
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || mimeType || "audio/mp4" });
        stream.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
        if (!blob.size) {
          setError("Safari did not return an audio file. Please record again.");
          setPhase("idle");
          return;
        }
        if (audioUrl) URL.revokeObjectURL(audioUrl);
        blobRef.current = blob;
        setSec(seconds);
        setAudioUrl(URL.createObjectURL(blob));
        setPhase("ready");
      };
      startRef.current = Date.now();
      setSec(0);
      recorder.start();
      setPhase("recording");
    } catch (err) {
      const denied = err?.name === "NotAllowedError" || err?.name === "SecurityError";
      setError(denied
        ? "Microphone access was denied. Allow microphone access for this site in Safari settings, then tap Record again."
        : "The microphone is unavailable. Check that no other app is using it and try again.");
      setPhase("idle");
    }
  };

  const stop = () => {
    if (recorderRef.current?.state !== "recording") return;
    setPhase("processing");
    recorderRef.current.stop();
  };

  const reRecord = () => {
    audioRef.current?.pause();
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioUrl(null);
    setPlaying(false);
    setSec(0);
    setError("");
    blobRef.current = null;
    setPhase("idle");
  };

  const togglePlay = async () => {
    if (!audioRef.current) return;
    if (audioRef.current.paused) {
      await audioRef.current.play();
      setPlaying(true);
    } else {
      audioRef.current.pause();
      setPlaying(false);
    }
  };

  const submit = async () => {
    if (!blobRef.current) return;
    const audioKey = `speaking-${Date.now()}`;
    try {
      await saveAudioBlob(audioKey, blobRef.current);
    } catch {
      setError("The recording could not be saved locally on this device. Keep this tab open and try recording again.");
      return;
    }
    onDone("speaking", {
      duration: mmss(sec), seconds: sec, audioKey,
      mimeType: blobRef.current.type, recordedAt: Date.now(), used: [],
    });
  };

  return (
    <>
      <ExerciseHeader title="Speaking" onExit={onExit} />
      <p className="el-serif" style={{ fontSize: 22, lineHeight: 1.35, margin: "0 0 18px" }}>
        {task.prompt || "Describe a demanding day when you had to deal with several problems."}
      </p>

      <div className="el-card" style={{ padding: 16 }}>
        <div className="el-eyebrow">You can talk about</div>
        <div style={{ display: "grid", gap: 7, marginTop: 10, fontSize: 14, color: "var(--ink2)" }}>
          {["what happened", "what had been planned in advance", "what had to be changed", "how you dealt with the problems", "what eventually happened"].map((x) => (
            <div key={x} style={{ display: "flex", gap: 9 }}><span style={{ color: "var(--ink3)" }}>—</span>{x}</div>
          ))}
        </div>
      </div>

      <div className="el-card" style={{ padding: 16, marginTop: 12 }}>
        <div className="el-eyebrow">Try to use</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 7, marginTop: 10 }}>
          {SPEAK_TARGETS.map((t) => <span key={t} className="el-pill" style={{ background: "var(--sunk)", color: "var(--ink2)" }}>{t}</span>)}
        </div>
      </div>

      <div style={{ textAlign: "center", marginTop: 34 }}>
        {phase !== "ready" && (
        <button onClick={phase === "recording" ? stop : start} disabled={["requesting", "processing"].includes(phase)}
          className={phase === "recording" ? "el-rec" : ""} style={{
            width: 96, height: 96, borderRadius: 999, background: phase === "recording" ? "var(--amber)" : "var(--accent)",
            color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 18px 34px -18px rgba(31,94,78,.7)", transition: "background .2s", opacity: ["requesting", "processing"].includes(phase) ? .65 : 1,
          }}>
          {phase === "recording" ? <Square size={28} fill="#fff" /> : <Mic size={34} strokeWidth={1.8} />}
        </button>
        )}
        <div className="el-mono" style={{ fontSize: 26, marginTop: 18, color: phase === "recording" ? "var(--ink)" : "var(--ink3)" }}>{mmss(sec)}</div>
        <div style={{ fontSize: 13, color: "var(--ink3)", marginTop: 6 }}>
          {phase === "requesting" ? "Запрашиваем доступ к микрофону…"
            : phase === "recording" ? "Идёт запись — нажмите Stop"
              : phase === "processing" ? "Сохраняем запись…"
                : phase === "ready" ? "Прослушайте запись перед отправкой"
                  : "Нажмите Record. Цель — 2 минуты."}
        </div>
        {error && <div className="el-card el-fadein" role="alert" style={{ padding: 13, marginTop: 14, textAlign: "left", color: "#9A4B3C", background: "#F8EAE6", borderColor: "#EBCFC8", fontSize: 13 }}>{error}</div>}

        {phase === "ready" && audioUrl && (
          <div className="el-card el-fadein" style={{ padding: 16, marginTop: 18, textAlign: "left" }}>
            <audio ref={audioRef} src={audioUrl} preload="metadata" playsInline
              onEnded={() => setPlaying(false)} onPause={() => setPlaying(false)} onPlay={() => setPlaying(true)} />
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <button className="el-btn el-p" onClick={togglePlay} style={{ width: 46, height: 46, borderRadius: 999, padding: 0 }}>
                {playing ? <Pause size={17} fill="#fff" /> : <Play size={17} fill="#fff" />}
              </button>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14.5, fontWeight: 560 }}>Your recording</div>
                <div className="el-mono" style={{ color: "var(--ink3)", fontSize: 12.5, marginTop: 3 }}>{mmss(sec)}</div>
              </div>
            </div>
            <button className="el-btn el-p" style={{ width: "100%", marginTop: 16, padding: 13 }} onClick={submit}>
              <Send size={15} /> Submit to teacher
            </button>
            <button className="el-btn el-g" style={{ width: "100%", marginTop: 9 }} onClick={reRecord}>
              <RotateCcw size={15} /> Re-record
            </button>
          </div>
        )}
        <div style={{ fontSize: 11.5, color: "var(--ink3)", marginTop: 14 }}>Microphone access is requested only after you tap Record.</div>
      </div>
    </>
  );
}

/* ------------------------- Student: Writing ------------------------- */

function WritingRunner({ task, onExit, onDone, notify }) {
  const [text, setText] = useState("");
  const [sent, setSent] = useState(false);
  const words = countWords(text);
  const used = usedTargets(text, WRITE_TARGETS);
  const ok = words >= 40;

  if (sent) return (
    <div className="el-fade" style={{ paddingTop: 30 }}>
      <div style={{
        width: 46, height: 46, borderRadius: 999, background: "var(--soft)", color: "var(--accent)",
        display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 18,
      }}><Check size={22} strokeWidth={2.2} /></div>
      <h2 className="el-serif" style={{ fontSize: 27, margin: "0 0 16px" }}>Writing submitted</h2>
      <div className="el-card" style={{ padding: 18, display: "grid", gap: 11 }}>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14 }}>
          <span style={{ color: "var(--ink2)" }}>Слов</span><span className="el-mono">{words}</span></div>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14 }}>
          <span style={{ color: "var(--ink2)" }}>Target expressions</span><span className="el-mono">{used.length}</span></div>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14 }}>
          <span style={{ color: "var(--ink2)" }}>Статус</span><span>Waiting for teacher feedback</span></div>
      </div>
      <button className="el-btn el-p" style={{ width: "100%", marginTop: 22, padding: 14, fontSize: 15 }}
        onClick={() => onDone("writing", { words, text, used })}>Continue</button>
    </div>
  );

  return (
    <>
      <ExerciseHeader title="Writing" onExit={onExit} />
      <p className="el-serif" style={{ fontSize: 21, lineHeight: 1.35, margin: "0 0 16px" }}>
        {task.prompt || "Write about a situation when a plan had to be changed unexpectedly."}
      </p>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 7, marginBottom: 16 }}>
        {(task.reqs || LIBRARY[2].reqs).map((r) => (
          <span key={r} className="el-pill" style={{ background: "var(--sunk)", color: "var(--ink2)" }}>{r}</span>
        ))}
      </div>

      <textarea className="el-ta" rows={11} placeholder="Начните писать…" value={text} onChange={(e) => setText(e.target.value)}
        style={{ fontFamily: "var(--serif)", fontSize: 16.5 }} />

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10 }}>
        <span className="el-mono" style={{ fontSize: 13, color: words >= 120 && words <= 160 ? "var(--accent)" : "var(--ink3)" }}>
          {words} / 120–160 words
        </span>
        <span style={{ fontSize: 12.5, color: "var(--ink3)" }}>
          {used.length ? `Использовано: ${used.length}` : "Target expressions: 0"}
        </span>
      </div>
      {used.length > 0 && (
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 10 }}>
          {used.map((u) => <span key={u} className="el-pill" style={{ background: "var(--soft)", color: "var(--accent)" }}><Check size={12} strokeWidth={2.6} />{u}</span>)}
        </div>
      )}

      <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
        <button className="el-btn el-g" onClick={() => notify("Draft saved")}>Save draft</button>
        <button className="el-btn el-p" style={{ flex: 1 }} disabled={!ok} onClick={() => setSent(true)}>Submit to teacher</button>
      </div>
      {!ok && (
        <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 10, display: "flex", justifyContent: "space-between", gap: 10 }}>
          <span>Нужно хотя бы 40 слов, чтобы отправить.</span>
          <button className="el-btn el-q" style={{ padding: 0, fontSize: 12.5, textDecoration: "underline" }}
            onClick={() => setText(SAMPLE_ESSAY)}>Вставить пример (демо)</button>
        </div>
      )}
    </>
  );
}

/* ------------------------- Student: Grammar ------------------------- */

function GrammarRunner({ task, onExit, onDone }) {
  const [i, setI] = useState(0);
  const [pick, setPick] = useState(null);
  const [correct, setCorrect] = useState(0);
  const [missed, setMissed] = useState([]);
  const [fin, setFin] = useState(false);
  const it = GRAMMAR_ITEMS[i];

  const choose = (j) => {
    if (pick !== null) return;
    setPick(j);
    if (j === it.a) setCorrect((c) => c + 1);
    else setMissed((m) => (m.includes(it.tag) ? m : [...m, it.tag]));
  };
  const next = () => {
    if (i + 1 >= GRAMMAR_ITEMS.length) setFin(true);
    else { setI(i + 1); setPick(null); }
  };

  if (fin) return (
    <div className="el-fade" style={{ paddingTop: 30 }}>
      <div className="el-eyebrow">Grammar in Context</div>
      <h2 className="el-serif" style={{ fontSize: 27, margin: "10px 0 18px" }}>Grammar completed</h2>
      <div className="el-card" style={{ padding: 20 }}>
        <div className="el-serif el-mono" style={{ fontSize: 30 }}>{correct} / {GRAMMAR_ITEMS.length}</div>
        <div style={{ fontSize: 13, color: "var(--ink3)", marginTop: 4 }}>верных с первой попытки</div>
        {missed.length > 0 && (
          <div style={{ marginTop: 14, borderTop: "1px solid var(--line)", paddingTop: 12 }}>
            <div className="el-eyebrow" style={{ marginBottom: 8 }}>Вернём на занятие</div>
            <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
              {missed.map((m) => <span key={m} className="el-pill" style={{ background: "var(--amber-s)", color: "var(--amber)" }}>{m}</span>)}
            </div>
          </div>
        )}
      </div>
      <button className="el-btn el-p" style={{ width: "100%", marginTop: 22, padding: 14, fontSize: 15 }}
        onClick={() => onDone("grammar", { correct, total: GRAMMAR_ITEMS.length, missed })}>Continue</button>
    </div>
  );

  return (
    <>
      <ExerciseHeader title="Grammar in Context" onExit={onExit} step={i + 1} of={GRAMMAR_ITEMS.length} />
      <div className="el-eyebrow">{it.tag}</div>
      <p className="el-serif" style={{ fontSize: 21, lineHeight: 1.4, margin: "12px 0 20px" }}>{it.s}</p>
      <div style={{ display: "grid", gap: 9 }}>
        {it.o.map((o, j) => {
          const isRight = j === it.a, chosen = pick === j;
          const show = pick !== null;
          return (
            <button key={o} className="el-card" onClick={() => choose(j)} style={{
              padding: "13px 16px", textAlign: "left", fontSize: 15.5, display: "flex", justifyContent: "space-between", alignItems: "center",
              background: show && isRight ? "var(--soft)" : show && chosen ? "var(--amber-s)" : "#fff",
              borderColor: show && isRight ? "#CFE0D9" : show && chosen ? "#EDDCC0" : "var(--line)",
            }}>
              {o}
              {show && isRight && <Check size={16} strokeWidth={2.4} color="var(--accent)" />}
            </button>
          );
        })}
      </div>
      {pick !== null && (
        <div className="el-fadein" style={{ marginTop: 16 }}>
          <div style={{ fontSize: 14, color: "var(--ink2)", lineHeight: 1.55 }}>
            <b style={{ color: pick === it.a ? "var(--accent)" : "var(--amber)", fontWeight: 600 }}>
              {pick === it.a ? "Exactly right. " : "Almost there. "}
            </b>{it.why}
          </div>
          <button className="el-btn el-p" style={{ width: "100%", marginTop: 16, padding: 13 }} onClick={next}>
            {i + 1 >= GRAMMAR_ITEMS.length ? "Готово" : "Next"}
          </button>
        </div>
      )}
    </>
  );
}

/* ------------------------- Student: feedback / progress / practice ------------------------- */

function StudentFeedback({ h, setRun, jumpToTeacher }) {
  if (!h || !h.feedback) return (
    <div style={{ paddingTop: 50, textAlign: "center" }}>
      <MessageSquare size={26} color="var(--ink3)" />
      <div className="el-serif" style={{ fontSize: 22, margin: "14px 0 8px" }}>Пока пусто</div>
      <p style={{ color: "var(--ink2)", fontSize: 14, lineHeight: 1.6 }}>
        Обратная связь появится, когда преподаватель проверит работу.
      </p>
      <button className="el-btn el-g" style={{ marginTop: 10 }} onClick={jumpToTeacher}>Проверить в режиме преподавателя</button>
    </div>
  );
  const f = h.feedback;
  const states = ["Needs practice", "Getting stronger", "Completed"];
  return (
    <>
      <div className="el-eyebrow" style={{ marginTop: 10 }}>Feedback from your teacher</div>
      <h1 className="el-serif" style={{ fontSize: 27, margin: "10px 0 18px" }}>{h.title}</h1>

      <div className="el-card" style={{ padding: 18 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <Avatar name="Мария" size={32} />
          <div style={{ fontSize: 13.5, fontWeight: 550 }}>Мария К.</div>
          {f.voice && <span className="el-pill" style={{ marginLeft: "auto", background: "var(--soft)", color: "var(--accent)" }}>
            <Play size={11} fill="currentColor" /> <span className="el-mono">{f.voice}</span></span>}
        </div>
        <p className="el-serif" style={{ fontSize: 16.5, lineHeight: 1.6, margin: "14px 0 0" }}>{f.text}</p>
      </div>

      <div className="el-card" style={{ padding: 18, marginTop: 12 }}>
        <div className="el-eyebrow">Your goals</div>
        <div style={{ display: "grid", gap: 12, marginTop: 12 }}>
          {h.goals.map((g, i) => {
            const st = f.goalStates[i];
            return (
              <div key={g} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                {st === 2 ? <CheckCircle2 size={15} color="var(--accent)" style={{ marginTop: 3 }} />
                  : st === 1 ? <TrendingUp size={15} color="var(--accent)" style={{ marginTop: 3 }} />
                    : <Circle size={13} color="var(--amber)" style={{ marginTop: 4 }} />}
                <div>
                  <div style={{ fontSize: 14.5 }}>{g}</div>
                  <div style={{ fontSize: 12.5, color: st === 0 ? "var(--amber)" : "var(--accent)", marginTop: 2 }}>{states[st]}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {(f.notes || []).length > 0 && (
        <div className="el-card" style={{ padding: 18, marginTop: 12 }}>
          <div className="el-eyebrow">Two sentences to review</div>
          <div style={{ display: "grid", gap: 14, marginTop: 12 }}>
            {f.notes.map((id) => {
              const p = ESSAY_PARTS.find((x) => x.id === id);
              return (
                <div key={id}>
                  <div className="el-serif" style={{ fontSize: 15.5, color: "var(--ink2)", lineHeight: 1.5 }}>«{p.t}»</div>
                  <div style={{ fontSize: 13.5, marginTop: 6, color: "var(--amber)" }}>{p.note}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {(f.marks || []).length > 0 && (
        <div className="el-card" style={{ padding: 18, marginTop: 12 }}>
          <div className="el-eyebrow">Пометки в записи</div>
          {f.marks.map((m, i) => (
            <div key={i} style={{ display: "flex", gap: 10, marginTop: 11, fontSize: 13.5 }}>
              <span className="el-mono" style={{ color: "var(--ink3)" }}>{mmss(Math.round(m.at * 124))}</span>{m.text}
            </div>
          ))}
        </div>
      )}

      <button className="el-btn el-p" style={{ width: "100%", marginTop: 20, padding: 14, fontSize: 15 }}
        onClick={() => setRun(LIBRARY[1])}>Practise again</button>
    </>
  );
}

function StudentProgress() {
  const Group = ({ title, items, tone }) => (
    <div className="el-card" style={{ padding: 18, marginTop: 12 }}>
      <div className="el-eyebrow" style={{ color: tone }}>{title}</div>
      <div style={{ display: "grid", gap: 13, marginTop: 13 }}>
        {items.map((x) => (
          <div key={x.t}>
            <div style={{ fontSize: 15, display: "flex", gap: 9, alignItems: "center" }}>
              <span style={{ width: 6, height: 6, borderRadius: 99, background: tone }} />{x.t}
            </div>
            <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 3, marginLeft: 15 }}>{x.note}</div>
          </div>
        ))}
      </div>
    </div>
  );
  return (
    <>
      <div className="el-eyebrow" style={{ marginTop: 10 }}>Progress</div>
      <h1 className="el-serif" style={{ fontSize: 29, margin: "10px 0 6px" }}>Your English</h1>
      <p style={{ color: "var(--ink2)", fontSize: 14, marginTop: 0 }}>
        Без очков и уровней. Только то, что уже работает само, и то, что ещё требует практики.
      </p>
      <Group title="Automatic" items={PROGRESS.automatic} tone="var(--accent)" />
      <Group title="Getting stronger" items={PROGRESS.stronger} tone="var(--blue)" />
      <Group title="Needs practice" items={PROGRESS.practice} tone="var(--amber)" />
      <div style={{ fontSize: 12.5, color: "var(--ink3)", marginTop: 16, lineHeight: 1.6 }}>
        Каждая строка меняется только после выполненных заданий — прогресс связан с практикой, а не с временем в приложении.
      </div>
    </>
  );
}

function StudentPractice({ hw, setRun, progress, active }) {
  const mine = Object.values(hw).filter((h) => h.student === "ahav");
  return (
    <>
      <div className="el-eyebrow" style={{ marginTop: 10 }}>Practice</div>
      <h1 className="el-serif" style={{ fontSize: 29, margin: "10px 0 16px" }}>Ваши задания</h1>
      {mine.map((h) => (
        <div key={h.id} className="el-card" style={{ padding: 16, marginBottom: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
            <span style={{ fontWeight: 550, fontSize: 15 }}>{h.title}</span>
            <Pill status={h.status} />
          </div>
          <div className="el-mono" style={{ fontSize: 12, color: "var(--ink3)", marginTop: 5 }}>
            Due {h.due} · {h.tasks.length} tasks
          </div>
        </div>
      ))}
      <div className="el-eyebrow" style={{ marginTop: 22, marginBottom: 10 }}>Потренироваться дополнительно</div>
      <div style={{ display: "grid", gap: 9 }}>
        {LIBRARY.map((l) => (
          <button key={l.id} className="el-card el-lift" onClick={() => setRun(l)}
            style={{ padding: 14, display: "flex", gap: 12, alignItems: "center", textAlign: "left" }}>
            <TaskIcon name={l.icon} size={16} />
            <span style={{ flex: 1 }}>
              <span style={{ display: "block", fontSize: 14.5, fontWeight: 550 }}>{l.title}</span>
              <span style={{ display: "block", fontSize: 12.5, color: "var(--ink3)" }}>{l.minutes} min</span>
            </span>
            <ChevronRight size={16} color="var(--ink3)" />
          </button>
        ))}
      </div>
    </>
  );
}

/* ================================================================== *
 *  ROOT
 * ================================================================== */

export default function EnglishLoop() {
  const [role, setRole] = useState("teacher");
  const [hw, setHw] = useState(loadHomework);
  const [toast, setToast] = useState(null);
  const notify = (m) => { setToast(m); setTimeout(() => setToast(null), 2400); };

  useEffect(() => {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(hw)); } catch { /* private mode can limit storage */ }
  }, [hw]);

  return (
    <div className="el-root">
      <style>{CSS}</style>
      <div style={{
        position: "sticky", top: 0, zIndex: 50, display: "flex", alignItems: "center", gap: 12,
        padding: "calc(9px + env(safe-area-inset-top)) 16px 9px", borderBottom: "1px solid var(--line)", background: "rgba(250,249,246,.92)", backdropFilter: "blur(10px)",
      }}>
        <span className="el-mono" style={{ fontSize: 11, letterSpacing: ".1em", color: "var(--ink3)", textTransform: "uppercase" }}>
          English Loop · Prototype
        </span>
        <div style={{ marginLeft: "auto", display: "flex", background: "var(--sunk)", borderRadius: 10, padding: 3 }}>
          {[{ k: "teacher", l: "Teacher" }, { k: "student", l: "Student" }].map((r) => (
            <button key={r.k} onClick={() => setRole(r.k)} style={{
              padding: "6px 14px", borderRadius: 8, fontSize: 13, fontWeight: 550,
              background: role === r.k ? "#fff" : "transparent",
              color: role === r.k ? "var(--ink)" : "var(--ink3)",
              boxShadow: role === r.k ? "0 1px 3px rgba(27,26,23,.12)" : "none", transition: "all .16s",
            }}>{r.l}</button>
          ))}
        </div>
        <button className="el-btn el-q" title="Сбросить демо" onClick={() => {
          window.localStorage.removeItem(STORAGE_KEY);
          clearAudioBlobs();
          setHw(initialHomework());
          notify("Демо сброшено");
        }}>
          <RotateCcw size={15} />
        </button>
      </div>

      {role === "teacher"
        ? <TeacherApp hw={hw} setHw={setHw} notify={notify} jumpToStudent={() => setRole("student")} />
        : <StudentApp hw={hw} setHw={setHw} notify={notify} jumpToTeacher={() => setRole("teacher")} />}

      <Toast show={!!toast}>{toast}</Toast>
    </div>
  );
}
